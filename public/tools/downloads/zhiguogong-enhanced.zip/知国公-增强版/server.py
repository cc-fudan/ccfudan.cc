"""Optional local server. Standard Python only; binds to loopback.
Run: python server.py  (or python server.py --port 8768)
"""
import argparse
import json
import sqlite3
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def do_GET(self):
        url = urlparse(self.path)
        if url.path == '/portable.html':
            target=ROOT.parent / '知国公-单文件版.html'
            if not target.exists():
                self.send_error(404,'Portable file not found next to enhanced folder')
                return
            content=target.read_bytes()
            self.send_response(200)
            self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Content-Length',str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        elif url.path == '/api/jobs':
            q = parse_qs(url.query)
            params = []
            clauses = []
            for key, column in [('city','location'),('major','major'),('department','department')]:
                if q.get(key):
                    clauses.append(column + ' LIKE ?')
                    params.append('%' + q[key][0] + '%')
            if q.get('id'):
                clauses.append('id = ?')
                params.append(q['id'][0])
            where = ' WHERE ' + ' AND '.join(clauses) if clauses else ''
            try:
                limit = max(1,min(int(q.get('limit',['100'])[0]),1000))
                offset = max(0,int(q.get('offset',['0'])[0]))
            except ValueError:
                self.send_error(400, 'Invalid pagination')
                return
            with sqlite3.connect((ROOT / 'jobs.sqlite').as_uri() + '?mode=ro',uri=True) as db:
                total = db.execute('SELECT COUNT(*) FROM jobs'+where,params).fetchone()[0]
                rows = db.execute('SELECT raw_json FROM jobs'+where+' ORDER BY id LIMIT ? OFFSET ?',params+[limit,offset]).fetchall()
            self.respond({'total':total,'offset':offset,'limit':limit,'jobs':[json.loads(r[0]) for r in rows]})
        elif url.path == '/api/status':
            self.respond({'mode':'local','liveCountsConnected':False,'database':'jobs.sqlite'})
        else:
            super().do_GET()

    def respond(self,value):
        content=json.dumps(value,ensure_ascii=False).encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(content)))
        self.send_header('Cache-Control','no-store')
        self.end_headers()
        self.wfile.write(content)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--port',type=int,default=8768)
    args=parser.parse_args()
    print(f'Local workbench: http://127.0.0.1:{args.port}/',flush=True)
    ThreadingHTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
