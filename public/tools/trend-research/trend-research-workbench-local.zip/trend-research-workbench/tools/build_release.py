"""Build a source-only ZIP with a strict allowlist; never include runtime data."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[1]
ROOT_FILES={'app.py','engine.py','research.py','structures.py','publication.py','restore_backup.py',
            'daily_refresh.py','daily_refresh.ps1','start.ps1','stop.ps1',
            '启动工作台.cmd','停止工作台.cmd','安装每日刷新任务.cmd','安装每日刷新任务.ps1',
            '卸载每日刷新任务.cmd','卸载每日刷新任务.ps1','README.md','LICENSE',
            'DISCLAIMER.md','THIRD_PARTY_NOTICES.md','PRIVACY.md','CONTRIBUTING.md','.gitignore'}
DIRECTORY_SUFFIXES={'assets':{'.json'},'static':{'.js','.css','.html'},
                    'docs':{'.md','.txt'},'strategy':{'.py'},'tests':{'.py'},'tools':{'.py'}}
EXCLUDED={'data','__pycache__','.qa','.git','node_modules','work','backups','outputs'}


def selected():
    paths=[]
    for p in ROOT.rglob('*'):
        if not p.is_file():continue
        rel=p.relative_to(ROOT)
        if EXCLUDED.intersection(rel.parts):continue
        if len(rel.parts)==1:
            if p.name in ROOT_FILES:paths.append(p)
        elif rel.parts[0] in DIRECTORY_SUFFIXES and p.suffix in DIRECTORY_SUFFIXES[rel.parts[0]]:
            paths.append(p)
    return sorted(paths,key=lambda p:p.relative_to(ROOT).as_posix())


def validate(paths):
    seed=json.loads((ROOT/'assets/bootstrap.json').read_text(encoding='utf-8'))
    if any(i.get('bars') for i in seed['instruments']):raise ValueError('Release must not redistribute market history')
    for p in paths:
        text=p.read_text(encoding='utf-8-sig')
        if str(Path.home()) in text or str(Path.home()).replace('\\','/') in text:
            raise ValueError('Local user path in release: '+str(p.relative_to(ROOT)))
        # No private or market artifacts can pass this file-type allowlist.
        if p.name in ('bootstrap.json','research-skill-contract.json'):continue
        if p.suffix=='.json':raise ValueError('Unexpected asset requiring review: '+p.name)


def build(destination):
    paths=selected();validate(paths)
    manifest={'project':'trend-research-workbench','version':'1.4.0','licence':'MIT',
              'includes_market_history':False,'includes_personal_records':False,
              'automatic_network_default':False,'files':[]}
    target=Path(destination).resolve();target.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for p in paths:
            rel=p.relative_to(ROOT).as_posix();body=p.read_bytes()
            manifest['files'].append({'path':rel,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()})
            archive.writestr('trend-research-workbench/'+rel,body)
        archive.writestr('trend-research-workbench/release-manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    return {'archive':target.name,'files':len(paths)+1,'bytes':target.stat().st_size,
            'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
            'market_history':False,'personal_records':False,'default_auto_network':False}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description='Build the source-only release')
    parser.add_argument('--output',type=Path,default=ROOT/'outputs'/'trend-research-workbench-1.4.0.zip')
    args=parser.parse_args()
    print(json.dumps(build(args.output),ensure_ascii=False,indent=2))
