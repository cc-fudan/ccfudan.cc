$ErrorActionPreference='Stop'
$record=Join-Path $PSScriptRoot 'data\server-process.json'
if (-not (Test-Path -LiteralPath $record)) { Write-Output 'No launcher process record. Stop the terminal server with Ctrl+C.'; exit 0 }
$info=Get-Content -LiteralPath $record -Raw | ConvertFrom-Json
$proc=Get-Process -Id $info.pid -ErrorAction SilentlyContinue
if (-not $proc) { Write-Output 'Recorded process is no longer running; no process was stopped.'; exit 0 }
$expectedApp=Join-Path $PSScriptRoot 'app.py'
if ($info.app -eq $expectedApp -and $info.executable -and $info.startedUtcTicks -and $proc.Path -eq $info.executable -and $proc.StartTime.ToUniversalTime().Ticks.ToString() -eq $info.startedUtcTicks) {
    Stop-Process -InputObject $proc
    Write-Output 'Workbench stopped. Data is retained.'
} else { throw 'Process identity does not match the launcher record. No process was stopped. Close the original server manually.' }
