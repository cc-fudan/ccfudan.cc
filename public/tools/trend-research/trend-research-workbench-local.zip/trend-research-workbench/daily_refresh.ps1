param([switch]$StartServerIfNeeded)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$python=Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
if (-not (Test-Path -LiteralPath $python)) { $python=(Get-Command python -ErrorAction Stop).Source }
$serverUrl='http://127.0.0.1:8766'
$request=[System.Net.HttpWebRequest]::Create($serverUrl+'/api/state');$request.Proxy=$null;$request.Timeout=1200
$online=$false
try { $response=$request.GetResponse();$response.Dispose();$online=$true } catch {}
if ($online) {
  $body=[Text.Encoding]::UTF8.GetBytes('{"reason":"Windows任务计划每日刷新"}')
  $post=[System.Net.HttpWebRequest]::Create($serverUrl+'/api/refresh-all');$post.Proxy=$null;$post.Method='POST';$post.ContentType='application/json';$post.ContentLength=$body.Length;$stream=$post.GetRequestStream();$stream.Write($body,0,$body.Length);$stream.Dispose();$resp=$post.GetResponse();$reader=New-Object IO.StreamReader($resp.GetResponseStream());$out=$reader.ReadToEnd();$reader.Dispose();$resp.Dispose();$out | Set-Content -LiteralPath (Join-Path $root 'data\last-refresh-result.json') -Encoding UTF8; exit 0
}
& $python (Join-Path $root 'daily_refresh.py') '--data-dir' (Join-Path $root 'data') | Set-Content -LiteralPath (Join-Path $root 'data\last-refresh-result.json') -Encoding UTF8
