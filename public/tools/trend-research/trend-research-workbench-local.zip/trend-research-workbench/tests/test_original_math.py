"""Calculation/temporal invariants, not evidence of profitable trading."""
import csv
import importlib.util
import io
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
from dataclasses import replace
from datetime import date, timedelta

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("trading_math", ROOT/"strategy"/"trading_math.py")
m = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = m
spec.loader.exec_module(m)


def bar(i, close, **kwargs):
    values = dict(date=(date(2025, 1, 1)+timedelta(days=i)).isoformat(),
                  open=close, high=close+.2, low=close-.2, close=close, volume=100, amount=20000000)
    values.update(kwargs)
    return m.Bar(**values)


def setup():
    b = [bar(i, 10+.05*i) for i in range(130)]
    for j in (110, 120):
        b[j] = replace(b[j], high=16.7)
    b.append(bar(130, 17.1, open=16.8, low=16.6, high=17.3, volume=200))
    return b


def sizing(**kwargs):
    v = dict(equity_base=100000, cash_base=100000, entry=20.4, stop=19.2,
             fx=1, lot=100, roundtrip_cost_per_share_quote=.08, fixed_cost_base=10,
             median_amount20_quote=20000000, existing_gross_base=0,
             existing_stop_risk_base=0, group_gross_base=0, group_stop_risk_base=0)
    v.update(kwargs)
    return v


class InputsAndMath(unittest.TestCase):
    def test_reject_nonfinite(self):
        for x in ("nan", "inf", "-inf"):
            with self.subTest(x=x), self.assertRaises(ValueError):
                m.size_trade(sizing(entry=x))

    def test_reject_corrupt_ohlc_and_dates(self):
        for b in ([bar(1, 20, high=19)], [bar(1, 20), bar(1, 21)],
                  [bar(2, 20), bar(1, 21)]):
            with self.assertRaises(ValueError):
                m.validate(b)

    def test_exact_slope_and_conditional_forecast(self):
        b = [bar(i, x) for i, x in enumerate((9, 10, 10, 13))]
        r = m.deduction(b, 3)
        self.assertAlmostEqual(r["actual_change"], (13-9)/3)
        self.assertEqual(r["next_outgoing"], 10)
        self.assertEqual(r["unchanged_next_close_estimate"], 1)
        future = b+[bar(4, 8)]
        self.assertLess(m.ma(future, 3)-m.ma(b, 3), 0)

    def test_missing_ma_does_not_use_shorter_window(self):
        self.assertIsNone(m.deduction(setup(), 250)["ma"])

    def test_read_csv_cuts_future_before_signal(self):
        b = setup()
        f = io.StringIO()
        w = csv.DictWriter(f, fieldnames=list(b[0].__dict__))
        w.writeheader()
        w.writerows(v.__dict__ for v in b+[bar(131, 100)])
        with patch("builtins.open", return_value=io.StringIO(f.getvalue())):
            self.assertEqual(m.read_csv("fixture.csv", b[-1].date), b)

    def test_full_precision_geometric_targets(self):
        r = m.targets(40, 30)
        self.assertEqual(r["arithmetic"], [50, 60, 70])
        self.assertAlmostEqual(r["logarithmic"][2], 40*(40/30)**3)
        self.assertIsNone(r["probability"])


class SignalTests(unittest.TestCase):
    def test_valid_research_signal(self):
        b = setup()
        r = m.signal(b, b)
        self.assertEqual(r["status"], "RESEARCH_SIGNAL", r["failed"])
        self.assertIn("UNVERIFIED", r["order_eligibility"])

    def test_boundary_and_volume_exclude_breakout_day(self):
        b = setup()
        r = m.signal(b, b)
        self.assertEqual(r["N"], 16.7)
        self.assertGreater(b[-1].high, r["N"])
        self.assertEqual(r["volume_ratio"], 2)

    def test_missing_benchmark_is_not_eligible(self):
        r = m.signal(setup())
        self.assertEqual(r["status"], "NO_SIGNAL")
        self.assertIn("benchmark", r["failed"])

    def test_unconfirmed_intraday_cross_is_not_signal(self):
        b = setup()
        b[-1] = replace(b[-1], close=16.6)
        self.assertFalse(m.signal(b, b)["checks"]["completed_breakout"])

    def test_stock_volume_and_etf_rule_distinct(self):
        b = setup()
        b[-1] = replace(b[-1], volume=100)
        self.assertFalse(m.signal(b, b, "stock")["checks"]["volume"])
        self.assertTrue(m.signal(b, b, "etf")["checks"]["volume"])


class SizingTests(unittest.TestCase):
    def test_fee_and_lot_round_down(self):
        r = m.size_trade(sizing())
        self.assertEqual(r["shares"], 100)  # (250-10)/1.28=187.5, rounded down
        self.assertAlmostEqual(r["planned_loss_base"], 138)
        self.assertAlmostEqual(r["position_value_base"], 2040)

    def test_one_lot_over_budget_skips(self):
        self.assertEqual(m.size_trade(sizing(lot=500))["shares"], 0)

    def test_combination_risk_cap_cannot_be_bypassed(self):
        self.assertEqual(m.size_trade(sizing(existing_stop_risk_base=950))["shares"], 0)
        self.assertEqual(m.size_trade(sizing(existing_stop_risk_base=490, group_stop_risk_base=490))["shares"], 0)

    def test_more_costs_or_adverse_fx_cannot_increase_size(self):
        base = m.size_trade(sizing(lot=1))["shares"]
        self.assertLess(m.size_trade(sizing(lot=1, fx=2))["shares"], base)
        self.assertLess(m.size_trade(sizing(lot=1, roundtrip_cost_per_share_quote=.5))["shares"], base)

    def test_gap_stress_can_exceed_planned_loss(self):
        r = m.size_trade(sizing())
        self.assertGreater(r["stress_loss_15pct_base"], r["planned_loss_base"])

    def test_reject_wide_stop_fractional_lot_and_inconsistent_group(self):
        for kwargs in (dict(stop=10), dict(lot=1.5), dict(group_gross_base=10)):
            with self.assertRaises(ValueError):
                m.size_trade(sizing(**kwargs))


class TrailTests(unittest.TestCase):
    def sample(self):
        b = [bar(i, 20) for i in range(60)]
        b.extend([
            bar(60, 21.8, open=21.5, high=22, low=21.2),
            bar(61, 22.2, open=22, high=22.5, low=21.5),
            bar(62, 21.6, open=21.5, high=22, low=20.8),
            bar(63, 21.8, low=21.1, high=22),
            bar(64, 22, low=21.3, high=22.3),
            bar(65, 20.9, open=20.2, low=20, high=21),
        ])
        return b

    def run_trail(self, b):
        return m.trail(b, b[59].date, 20, 18, .5)

    def test_pivot_needs_two_future_bars_and_next_day_effect(self):
        b = self.sample()
        before = self.run_trail(b[:64])["records"]
        self.assertTrue(all(r["confirmed_pivot_date"] != b[62].date for r in before))
        r = self.run_trail(b)["records"]
        confirm = next(x for x in r if x["date"] == b[64].date)
        self.assertEqual(confirm["effective_stop"], 18)
        self.assertEqual(confirm["confirmed_pivot_date"], b[62].date)
        self.assertAlmostEqual(confirm["next_stop"], 20.3)
        self.assertEqual(r[-1]["reason"], "OPEN_STOP")
        self.assertAlmostEqual(r[-1]["effective_stop"], 20.3)

    def test_future_append_does_not_repaint_previous_records(self):
        b = self.sample()
        prefix = self.run_trail(b[:65])["records"]
        full = self.run_trail(b)["records"]
        self.assertEqual(prefix, full[:len(prefix)])
        self.assertTrue(all(x["next_stop"] >= x["effective_stop"] for x in full))

    def test_open_stop_record_cannot_use_later_close(self):
        b = self.sample()
        original = self.run_trail(b)["records"][-1]
        b[-1] = replace(b[-1], close=30, high=30)
        changed = self.run_trail(b)["records"][-1]
        self.assertEqual(original, changed)
        self.assertEqual(original["knowledge_at"], "OPEN")

    def test_numeric_string_stop_is_normalized(self):
        b = [bar(i, 20) for i in range(80)]
        r = m.trail(b, b[59].date, "20", "18", "0.5")
        self.assertEqual(r["records"][-1]["reason"], "NO_PROGRESS_20")

    def test_entry_day_open_is_not_retroactive_stop(self):
        b = self.sample()[:60]
        b[59] = replace(b[59], open=17, low=17)
        self.assertEqual(self.run_trail(b)["status"], "HOLD_RESEARCH")

    def test_close_stop_creates_task_without_fill(self):
        b = self.sample()[:60]+[bar(60, 17.5, open=19, high=19, low=17)]
        r = self.run_trail(b)
        self.assertEqual(r["status"], "EXIT_REQUIRED_NEXT_SESSION")
        self.assertIn("not simulated", r["fills"])

    def test_twenty_day_no_progress(self):
        b = [bar(i, 20) for i in range(60)]
        b += [bar(i, 20.5) for i in range(60, 90)]
        r = self.run_trail(b)["records"][-1]
        self.assertEqual(r["held"], 20)
        self.assertEqual(r["reason"], "NO_PROGRESS_20")

    def test_sixty_day_hard_time_exit(self):
        b = [bar(i, 20) for i in range(60)]
        b += [bar(i, 22.1) for i in range(60, 130)]
        r = self.run_trail(b)["records"][-1]
        self.assertEqual(r["held"], 60)
        self.assertEqual(r["reason"], "MAX_HOLD_60")


if __name__ == "__main__":
    unittest.main(verbosity=2)
