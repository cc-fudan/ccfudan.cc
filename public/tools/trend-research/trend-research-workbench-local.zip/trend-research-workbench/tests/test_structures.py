"""Generated paths test geometry, causal timing, lifecycle and accounting isolation.

No historical recognition accuracy or profitability is inferred from these tests.
"""
import copy
import json
import os
from pathlib import Path
import sys
import unittest
import uuid
from datetime import date,timedelta

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import structures as s
import engine as e
import app
import research
from restore_backup import restore


def path(vertices, end=None):
    rows=[]
    for (i,a),(j,z) in zip(vertices,vertices[1:]):
        for k in range(i,j):
            c=a+(z-a)*(k-i)/(j-i)
            rows.append(e.mathv1.Bar((date(2025,1,1)+timedelta(days=k)).isoformat(),c-.05,c+.4,c-.4,c,100,None))
    j,c=vertices[-1]
    rows.append(e.mathv1.Bar((date(2025,1,1)+timedelta(days=j)).isoformat(),c-.05,c+.4,c-.4,c,100,None))
    return rows[:end] if end else rows


DOUBLE=[(0,125),(40,90),(50,101),(60,90.5),(68,98),(70,104),(71,105),(72,101.6),(73,103),(74,108),(75,109),(76,98),(80,97)]
HS=[(0,125),(40,96),(50,105),(60,89),(70,104),(80,96),(88,101),(90,108),(95,110)]
TRIANGLE=[(0,80),(40,110),(46,90),(52,108),(58,93),(64,106),(70,96),(76,99),(80,110)]


def sample(b):
    i=e.instrument_input(dict(id='sh600001',name='结构测试',benchmark='sh000300',group='合成'))
    return {**i,'bars':[x.__dict__ for x in b],'meta':{'adjustment':'synthetic','completed_confirmed':True}}


def family(b,name,radius=2):
    return [x for x in s.scan(b) if x['family']==name and x['radius']==radius]


class StructureTests(unittest.TestCase):
    def test_double_bottom_pretrend_geometry_and_own_neckline(self):
        b=path(DOUBLE);patterns=family(b,'double_bottom')
        self.assertTrue(patterns)
        x=next(x for x in patterns if x['anchors'][0]['index']==40)
        self.assertEqual(x['pretrend']['direction'],'down')
        self.assertAlmostEqual(s.level(x['neck'],62),b[50].high)
        self.assertEqual(x['known_index'],62)
        self.assertNotEqual(s.level(x['neck'],74),max(v.high for v in b[54:74]))

    def test_double_top_is_directional_and_not_a_buy(self):
        b=path([(i,220-v) for i,v in DOUBLE]);patterns=family(b,'double_top')
        self.assertTrue(patterns)
        self.assertEqual(patterns[0]['direction'],-1)
        q=s.analyze(b);cross=s.cross_validate(q,False,True,'NO_SIGNAL')
        self.assertTrue(any('仅做多' in x['note'] for x in cross))

    def test_reject_wrong_pretrend_and_asymmetric_lows(self):
        b=path([(0,85),*DOUBLE[1:]])
        self.assertFalse(any(x['anchors'][0]['index']==40 for x in family(b,'double_bottom')))
        b=path([(i,95 if i==60 else v) for i,v in DOUBLE])
        self.assertFalse(any(x['anchors'][0]['index']==40 for x in family(b,'double_bottom')))

    def test_inverse_and_normal_head_shoulders_have_two_neck_anchors(self):
        for vertices,name in ((HS,'inverse_hs'),([(i,220-v) for i,v in HS],'hs')):
            patterns=family(path(vertices),name)
            self.assertTrue(patterns,name)
            x=next(x for x in patterns if x['anchors'][0]['index']==40)
            self.assertEqual(len(x['neck']['anchors']),2)
            self.assertNotEqual(x['neck']['slope'],0)

    def test_reject_head_not_deeper_than_shoulders(self):
        b=path([(i,96.2 if i==60 else v) for i,v in HS])
        self.assertFalse(any(x['anchors'][0]['index']==40 for x in family(b,'inverse_hs')))

    def test_three_triangle_types_and_rectangle(self):
        cases=[(TRIANGLE,'sym_triangle'),
               ([(i,110 if i in (40,52,64) else v) for i,v in TRIANGLE],'ascending_triangle'),
               ([(i,90 if i in (46,58,70) else v) for i,v in TRIANGLE],'descending_triangle'),
               ([(i,110 if i in (40,52,64) else 100 if i in (46,58,70) else 105 if i==76 else v) for i,v in TRIANGLE],'rectangle')]
        for vertices,name in cases:
            found=family(path(vertices),name)
            self.assertTrue(found,name)
            self.assertEqual(len(found[0]['upper']['anchors']),3)
            self.assertEqual(len(found[0]['lower']['anchors']),3)

    def test_invalid_triangle_middle_touch_is_rejected(self):
        b=path([(i,115 if i==52 else v) for i,v in TRIANGLE])
        self.assertFalse(family(b,'sym_triangle'))

    def test_no_candidate_until_right_pivots_confirmed(self):
        b=path(DOUBLE)
        self.assertFalse(family(b[:62],'double_bottom'))
        self.assertTrue(family(b[:63],'double_bottom'))
        self.assertTrue(all(a['confirmed_on']<=x['known_on'] for x in s.scan(b) for a in x['anchors']))

    def test_all_prefix_events_unchanged_after_append(self):
        b=path(DOUBLE);full={x['id']:x for x in s.scan(b)}
        for end in range(63,len(b)):
            for x in s.scan(b[:end]):
                self.assertIn(x['id'],full)
                self.assertEqual(x['events'],[ev for ev in full[x['id']]['events'] if ev['index']<end])
                self.assertEqual(x['neck'],full[x['id']]['neck'])

    def test_breakout_retest_later_hold_continuation_then_failure_retained(self):
        x=family(path(DOUBLE),'double_bottom')[0]
        states=[ev['state'] for ev in x['events']]
        self.assertEqual(states,['candidate','breakout','retest','held','continuation','failed'])
        self.assertGreater(x['events'][3]['index'],x['events'][2]['index'])
        self.assertIn('breakout',states)
        self.assertEqual(x['state'],'failed')

    def test_close_failure_wins_over_intraday_retest(self):
        b=path(DOUBLE);b=b[:72]+path([(0,100),(1,98)])[1:]
        # Keep dates strictly ordered for the altered last completed bar.
        b[-1]=e.mathv1.Bar((date(2025,1,1)+timedelta(days=72)).isoformat(),103,106,97,98,100,None)
        x=family(b,'double_bottom')[0]
        self.assertEqual(x['state'],'failed')
        self.assertNotIn('retest',[ev['state'] for ev in x['events']])

    def test_expiry_and_prebreak_extreme_invalidation(self):
        for tail,state in (([(63,92),(130,98)],'expired'), ([(63,92),(66,85)],'invalidated')):
            b=path(DOUBLE[:4]+tail)
            x=next(x for x in family(b,'double_bottom') if x['anchors'][0]['index']==40)
            self.assertEqual(x['state'],state)

    def test_conflicting_candidate_directions_are_preserved(self):
        up=s.analyze(path(DOUBLE[:4]+[(63,92)]))['patterns'][0]
        down=copy.deepcopy(up);down.update(id='opposite',name='双顶',expected_direction=-1)
        report=dict(patterns=[up,down])
        rows=s.cross_validate(report,False,True,'NO_SIGNAL')
        self.assertEqual(len(rows),2)
        self.assertEqual(rows[0]['execution'],'V1不允许建立新仓')
        self.assertIn('冲突',rows[0]['relation'])
        self.assertIn('未突破',rows[0]['relation'])

    def test_bullish_structure_conflicts_with_bearish_ma(self):
        q=s.analyze(path(DOUBLE[:10]));cross=s.cross_validate(q,False,True,'NO_SIGNAL')
        self.assertTrue(any(x['relation']=='冲突' for x in cross))
        self.assertTrue(all(x['execution']=='V1不允许建立新仓' for x in cross))

    def test_persistence_append_revision_restore_and_read_only(self):
        directory=Path(os.environ.get('WORKBENCH_QA_DIR',ROOT/'tests/.qa'))/('structures-'+uuid.uuid4().hex[:8])
        store=app.Store(directory);i=sample(path(DOUBLE,end=74))
        store.put('instrument',i['id'],i,'synthetic')
        first=store.get('settings','structure:'+i['id'])
        before=store.export();app.detail_payload(store,i['id'])
        self.assertEqual(before['objects'],store.export()['objects'])
        self.assertEqual(before['revisions'],store.export()['revisions'])
        i=sample(path(DOUBLE));store.put('instrument',i['id'],i,'append')
        after=store.get('settings','structure:'+i['id'])
        self.assertEqual(first['generation'],after['generation'])
        identity=first['report']['patterns'][0]['id']
        self.assertEqual(first['first_observed'][identity],after['first_observed'][identity])
        i['bars'][45]['close']+=.01;store.put('instrument',i['id'],i,'vendor correction')
        revised=store.get('settings','structure:'+i['id'])
        self.assertEqual(revised['generation'],after['generation']+1)
        self.assertTrue(revised['revision_detected'])
        self.assertEqual(store.list('trade'),[]);self.assertEqual(store.list('plan'),[])
        export=directory/'backup.json';export.write_text(json.dumps(store.export()),encoding='utf-8')
        restore(export,directory/'restored')
        restored=app.Store(directory/'restored')
        self.assertEqual(restored.get('settings','structure:'+i['id']),revised)
        self.assertEqual(restored.export()['revisions'],store.export()['revisions'])

    def test_adjustment_change_starts_new_generation(self):
        i=sample(path(DOUBLE));old=s.tracking(i,'first')
        i['meta']['adjustment']='changed';new=s.tracking(i,'second',old)
        self.assertTrue(new['revision_detected']);self.assertEqual(new['generation'],2)

    def test_rolling_window_archives_history_without_revising_generation(self):
        i=sample(path(DOUBLE));old=s.tracking(i,'first')
        candidate=next(iter(old['archive']))
        i['bars']=i['bars'][35:]
        new=s.tracking(i,'second',old)
        self.assertFalse(new['revision_detected']);self.assertEqual(new['generation'],1)
        self.assertIn(candidate,new['archive'])
        self.assertIn(candidate,new['first_observed'])

    def test_missing_overlap_bar_and_backfill_start_new_generation(self):
        i=sample(path(DOUBLE));old=s.tracking(i,'first')
        deleted=copy.deepcopy(i);del deleted['bars'][50]
        self.assertTrue(s.tracking(deleted,'second',old)['revision_detected'])
        tail=copy.deepcopy(i);tail['bars']=tail['bars'][5:]
        prior=s.tracking(tail,'first')
        self.assertTrue(s.tracking(i,'second',prior)['revision_detected'])

    def test_new_events_have_separate_actual_observation_time(self):
        i=sample(path(DOUBLE,end=70));first=s.tracking(i,'first')
        i=sample(path(DOUBLE));last=s.tracking(i,'second',first)
        key=next(key for key in last['event_observed'] if key.endswith('/breakout'))
        self.assertEqual(last['event_observed'][key],'second')
        candidate=key.split('/')[0]
        self.assertEqual(last['first_observed'][candidate],'first')

    def test_failed_lines_stop_at_failure_date(self):
        b=path(DOUBLE);q=s.analyze(b);lines=s.chart_lines(q,b)
        for x in q['patterns']:
            if x['state']=='failed':
                own=[l for l in lines if l['structure_id']==x['id']]
                self.assertTrue(own)
                self.assertTrue(all(l['end_date']==x['events'][-1]['date'] for l in own))

    def test_short_data_still_has_independent_structures_and_no_execution(self):
        i=sample(path(DOUBLE));q=research.build(i,{})
        self.assertTrue(q['structures']['patterns']);self.assertTrue(q['lines'])
        self.assertFalse(q.get('execution'));json.dumps(q,allow_nan=False)

    def test_explicit_scan_leaves_existing_frozen_objects_untouched(self):
        directory=Path(os.environ.get('WORKBENCH_QA_DIR',ROOT/'tests/.qa'))/('isolation-'+uuid.uuid4().hex[:8])
        store=app.Store(directory);i=sample(path(DOUBLE))
        store.put('instrument',i['id'],i,'synthetic')
        store.put('plan','frozen',{'symbol':i['id'],'initial_stop':88,'frozen':True},'synthetic frozen')
        store.put('trade','existing',{'symbol':i['id'],'initial_stop':88,'fills':[]},'synthetic position')
        before={kind:store.list(kind) for kind in ('plan','trade','instrument')}
        app.mutate(store,'/api/structures/scan',{'symbol':i['id']})
        self.assertEqual(before,{kind:store.list(kind) for kind in before})

    def test_algorithm_version_change_starts_generation_and_resets_observation(self):
        i=sample(path(DOUBLE));old=s.tracking(i,'first');old['version']='prior-definition'
        new=s.tracking(i,'second',old)
        self.assertEqual(new['generation'],2)
        self.assertTrue(all(v=='second' for v in new['first_observed'].values()))
        self.assertIn('算法版本',new['data_change'])

    def test_scan_delta_only_reports_post_snapshot_events(self):
        i=sample(path(DOUBLE,end=71));old=s.tracking(i,'first')
        i=sample(path(DOUBLE));new=s.tracking(i,'second',old)
        self.assertTrue(new['changes_since_previous']['compared'])
        self.assertTrue(new['changes_since_previous']['new_events'])
        self.assertTrue(all(x['date']>old['asof'] for x in new['changes_since_previous']['new_events']))
        self.assertEqual(new['changes_since_previous']['new_events'][0]['first_observed_at'],'second')


    def test_terminal_direction_cannot_be_reported_as_ma_agreement(self):
        pattern=dict(id='failed-up',name='test',state='failed',state_label='失败',direction=1,expected_direction=1)
        rows=s.cross_validate({'patterns':[pattern]},True,False,'NO_SIGNAL')
        self.assertEqual(rows[0]['relation'],'结构已失效/到期')


if __name__=='__main__':unittest.main()
