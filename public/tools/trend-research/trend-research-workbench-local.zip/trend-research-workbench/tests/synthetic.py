"""Synthetic OHLCV for tests only. These are not historical market quotes."""
from datetime import date,timedelta


def populate(store):
    for item in store.list('instrument'):
        rows=[]
        for j in range(150):
            c=10+.02*j+(.08 if j%8<4 else -.08)
            rows.append({'date':(date(2025,1,1)+timedelta(days=j)).isoformat(),
                         'open':c-.03,'high':c+.2,'low':c-.2,'close':c,
                         'volume':100+j%7,'amount':20000000})
        store.put('instrument',item['id'],{**item,'bars':rows,
            'meta':{'source':'SYNTHETIC TEST INPUT - NOT MARKET DATA','completed_confirmed':True,
                    'adjustment_verified':True,'completed_through':rows[-1]['date']}},'synthetic test fixture')
    return store
