"""Method-report timing, honesty and isolation from the execution engine."""
import copy
import json
import os
import sys
import unittest
import uuid
from datetime import date,timedelta
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import engine as e
import research as r
import app
from synthetic import populate


def instrument(count=150):
    rows=[]
    for i in range(count):
        c=30-i*.04+(.6 if i%12<6 else -.6)
        rows.append(dict(date=(date(2025,1,1)+timedelta(days=i)).isoformat(),open=c+.1,high=c+.4,low=c-.4,close=c,volume=100+i%5,amount=None))
    return {**e.instrument_input(dict(id='sh600001',name='测试股票',group='测试',benchmark='sh000300')),
            'bars':rows,'meta':{'source':'fixture','completed_confirmed':True,'adjustment_verified':False}}


def universe(count=150):
    i=instrument(count)
    benchmark={**copy.deepcopy(i),'id':'sh000300','name':'测试基准','kind':'index'}
    return {i['id']:i,benchmark['id']:benchmark}


class ResearchTests(unittest.TestCase):
    def test_no_unconfirmed_last_two_bar_pivot_and_confirmation_time(self):
        b=e.bars_of(instrument(30))
        j=20
        rows=instrument(30)['bars']
        rows[j]['high']=80
        i={**instrument(30),'bars':rows}
        full=r.pivots(e.bars_of(i))['high']
        point=next(p for p in full if p['index']==j)
        self.assertEqual(point['confirmed_on'],rows[j+2]['date'])
        before=r.pivots(e.bars_of({**i,'bars':rows[:j+2]}))['high']
        self.assertNotIn(j,[p['index'] for p in before])
        self.assertTrue(all(p['index']<=len(rows)-3 for p in full))

    def test_trendline_rejects_many_body_cuts(self):
        rows=[]
        for i in range(30):
            rows.append(dict(date=(date(2025,1,1)+timedelta(days=i)).isoformat(),open=19,high=22,low=18,close=21,volume=10,amount=None))
        for i in (5,20):rows[i].update(open=18,close=19,high=20)
        b=e.bars_of({**instrument(),'bars':rows})
        points=[r.anchor(b,5,'high',7),r.anchor(b,20,'high',22)]
        self.assertIsNone(r.trendline(b,points,'high',.1))

    def test_crossed_trendline_is_explicitly_marked_as_reassess(self):
        rows=[]
        for i in range(30):
            rows.append(dict(date=(date(2025,1,1)+timedelta(days=i)).isoformat(),open=18,high=19,low=17,close=18.5,volume=10,amount=None))
        for i in (5,20):rows[i]['high']=20
        for i in (27,28,29):rows[i].update(open=21,high=23,low=20,close=22)
        b=e.bars_of({**instrument(),'bars':rows})
        line=r.trendline(b,[r.anchor(b,5,'high',7),r.anchor(b,20,'high',22)],'high',.1)
        self.assertEqual(line['first_close_violation'],rows[27]['date'])
        self.assertEqual(line['post_anchor_violations'],3)
        self.assertIn('重估',line['status'])

    def test_skill_mapping_matches_and_package_has_all_referenced_context(self):
        skill=r.skill_context(True)
        self.assertTrue(skill['mapping_verified'])
        self.assertTrue(skill['loaded'])
        self.assertIn('references/data-contract.md',[d['name'] for d in skill['documents']])
        self.assertIn('assets/trade-record.md',[d['name'] for d in skill['documents']])

    def test_report_does_not_change_v1_or_issue_order_when_bearish(self):
        u=universe();i=u['sh600001']
        original=copy.deepcopy(i)
        before=e.analyze(i,u)
        q=r.build(i,u)
        self.assertEqual(i,original)
        self.assertEqual(e.analyze(i,u),before)
        self.assertEqual(q['execution']['status'],'NO_SIGNAL')
        self.assertTrue(q['execution']['failed'])
        self.assertIn('先观察',q['next_action'])
        self.assertNotIn('shares',q['execution'])
        json.dumps(q,allow_nan=False)

    def test_all_line_anchors_known_and_last_day_excluded_from_box(self):
        u=universe();q=r.build(u['sh600001'],u)
        for line in q['lines']:
            self.assertLessEqual(line['known_on'],q['asof'])
            for p in line['anchors']:self.assertLessEqual(p['confirmed_on'],q['asof'])
            if line['kind']=='v1':
                self.assertTrue(all(p['date']<q['asof'] for p in line['anchors']))
        self.assertEqual({x['id'] for x in q['lines'] if x['kind']=='v1'},{'N','D'})

    def test_exact_deduction_and_short_background_sample(self):
        b=e.bars_of(instrument(150));ma={x['period']:x for x in r.moving_averages(b)}
        self.assertAlmostEqual(ma[60]['next_outgoing_close'],b[-60].close)
        self.assertAlmostEqual(ma[60]['actual_day_change'],(b[-1].close-b[-61].close)/60)
        self.assertIsNone(ma[250]['value'])
        q=r.build(instrument(100),{})
        self.assertFalse(q['lines']);self.assertEqual(q['regime'],'待数据')

    def test_prefix_report_not_changed_by_later_prices_when_truncated(self):
        u=universe(160)
        prefix={k:{**v,'bars':copy.deepcopy(v['bars'][:150])} for k,v in u.items()}
        baseline=r.build(prefix['sh600001'],prefix)
        for i in u.values():
            for b in i['bars'][150:]:b.update(open=1000,high=1100,low=900,close=1000)
        truncated={k:{**v,'bars':v['bars'][:150]} for k,v in u.items()}
        self.assertEqual(baseline,r.build(truncated['sh600001'],truncated))

    def test_export_contains_corrected_skill_and_discloses_no_model(self):
        u=universe();q=r.build(u['sh600001'],u)
        pack=r.ai_bundle(u['sh600001'],u,q)
        self.assertTrue(pack['skill']['loaded'])
        self.assertEqual(pack['skill']['name'],'trend-research-system')
        self.assertTrue(all(d['text'] and d['sha256'] for d in pack['skill']['documents']))
        self.assertIn('未调用大模型',q['skill']['mode'])
        self.assertNotIn('account',pack)
        self.assertNotIn('trades',pack)
        self.assertIn('空仓如何做',r.markdown(q))
        self.assertIn('盘面复盘与后续观察',q['article']['title'])
        self.assertEqual(len(q['article']['sections']),7)
        self.assertIn('接下来不是一个答案',q['article']['sections'][4]['title'])

    def test_detail_and_export_routes_are_read_only(self):
        directory=Path(os.environ.get('WORKBENCH_QA_DIR',ROOT/'tests'/'.qa'))/('research-'+uuid.uuid4().hex[:8])
        store=populate(app.Store(directory))
        before=store.export()
        detail=app.detail_payload(store,'hk01810')
        self.assertIn('research',detail)
        self.assertTrue(detail['research']['paragraphs'])
        self.assertEqual(store.export()['revisions'],before['revisions'])
        self.assertEqual(store.export()['objects'],before['objects'])


if __name__=='__main__':unittest.main()
