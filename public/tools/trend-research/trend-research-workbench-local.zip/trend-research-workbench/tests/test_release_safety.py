"""Publication boundaries: no private content, data licence or automatic network assumption."""
import json
import os
import sys
import threading
import unittest
import urllib.request
import uuid
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import app
import research
import publication


class PublicationTests(unittest.TestCase):
    def test_bootstrap_contains_catalog_only_and_no_market_history(self):
        seed=json.loads((ROOT/'assets/bootstrap.json').read_text(encoding='utf-8'))
        self.assertTrue(seed['instruments'])
        self.assertTrue(all(not i['bars'] for i in seed['instruments']))

    def test_fresh_state_has_no_automatic_network_and_can_change_preference(self):
        path=Path(os.environ.get('WORKBENCH_QA_DIR',ROOT/'tests/.qa'))/('publication-'+uuid.uuid4().hex[:8])
        store=app.Store(path)
        state=app.overview(store)
        self.assertFalse(state['refresh_preferences']['enabled'])
        self.assertTrue(all(i['state']=='待数据' for i in state['stocks']))
        self.assertIn('purpose',state['notice'])
        app.mutate(store,'/api/refresh-preferences',{'enabled':True})
        self.assertTrue(app.overview(store)['refresh_preferences']['enabled'])
        app.mutate(store,'/api/refresh-preferences',{'enabled':False})
        self.assertFalse(app.overview(store)['refresh_preferences']['enabled'])

    def test_public_source_and_documents_have_no_source_brand(self):
        forbidden=[chr(0x59da)+chr(0x5c27),'yao'+'yao',chr(0x80a1)+chr(0x5e02)+chr(0x5747)+chr(0x7ebf)+chr(0x5b66),
                   chr(0x80a1)+chr(0x5e02)+chr(0x5f62)+chr(0x6001)+chr(0x5b66)]
        for p in ROOT.rglob('*'):
            if not p.is_file() or any(x in ('data','__pycache__','.qa') for x in p.relative_to(ROOT).parts):continue
            if p.name=='release-manifest.json':continue
            if p.suffix not in ('.py','.js','.md','.json','.html','.ps1','.cmd','.css') and p.name!='LICENSE':continue
            text=p.read_text(encoding='utf-8-sig').lower()
            for name in forbidden:
                self.assertNotIn(name.lower(),text,str(p.relative_to(ROOT)))

    def test_method_context_is_local_and_export_contains_notice(self):
        context=research.skill_context(True)
        self.assertEqual(context['name'],'trend-research-system')
        self.assertTrue(context['mapping_verified'])
        seed=json.loads((ROOT/'assets/bootstrap.json').read_text(encoding='utf-8'))['instruments']
        u={i['id']:i for i in seed}
        i=next(x for x in seed if x['kind']=='stock')
        report=research.build(i,u)
        self.assertEqual(report['usage_notice'],publication.NOTICE)
        self.assertIn('不构成',research.markdown(report))
        package=research.ai_bundle(i,u,report)
        self.assertEqual(package['usage_notice'],publication.NOTICE)
        self.assertNotIn('account',package)

    def test_legal_page_and_api_notices_are_served_without_private_files(self):
        path=Path(os.environ.get('WORKBENCH_QA_DIR',ROOT/'tests/.qa'))/('legal-http-'+uuid.uuid4().hex[:8])
        server=app.create_server(0,path)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        url='http://127.0.0.1:'+str(server.server_port)
        try:
            with opener.open(url+'/legal.html',timeout=5) as response:
                text=response.read().decode('utf-8')
                self.assertIn('免责声明不自动',text)
            with opener.open(url+'/api/state',timeout=5) as response:
                state=json.load(response)
                self.assertEqual(state['usage_notice'],publication.NOTICE)
            with opener.open(url+'/docs/license.txt',timeout=5) as response:
                self.assertIn(b'MIT License',response.read())
            with self.assertRaises(urllib.error.HTTPError):opener.open(url+'/data/workbench.sqlite3',timeout=5)
        finally:
            server.shutdown();server.server_close();thread.join(timeout=2)


if __name__=='__main__':unittest.main()
