"""Accounting, data provenance and local API invariants, not profitability tests."""
import copy
import csv
import io
import json
import os
import sys
import threading
import unittest
import urllib.request
import urllib.error
import uuid
from pathlib import Path
from datetime import date,timedelta
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
QA_ROOT=Path(os.environ.get('WORKBENCH_QA_DIR',ROOT/'tests'/'.qa')).resolve()
sys.path.insert(0,str(ROOT))
import app
import engine as e
from restore_backup import restore
from synthetic import populate


def series():
    rows=[]
    for i in range(130):
        c=10+.05*i
        rows.append(dict(date=(date(2025,1,1)+timedelta(days=i)).isoformat(),open=c,close=c,high=c+.2,low=c-.2,volume=100,amount=20000000))
    for j in (110,120): rows[j]['high']=16.7
    rows.append(dict(date='2025-05-11',open=16.8,close=17.1,high=17.3,low=16.6,volume=200,amount=20000000))
    return rows


def fixture_universe():
    return {sid:{**e.instrument_input(dict(id=sid,name=sid,kind=kind,benchmark='sh000300',group='one')),
                 'bars':series(),'meta':{'completed_confirmed':True,'adjustment_verified':True}}
            for sid,kind in [('sh600001','stock'),('sh000300','index')]}


def trade(mode='real'):
    return dict(symbol='hk01810',name='小米',mode=mode,thesis='买前理由',notes='',adherence='unknown',
                initial_stop=9,buffer=1,initial_risk_base=100,plan_id='',fills=[
                    dict(date='2025-01-01',side='buy',quantity=100,price=10,fee=10,fx=.9),
                    dict(date='2025-01-02',side='sell',quantity=40,price=12,fee=4,fx=.91)])


class EngineTests(unittest.TestCase):
    def test_benchmark_must_align_and_missing_is_not_candidate(self):
        u=fixture_universe();self.assertEqual(e.analyze(u['sh600001'],u)['state'],'价格条件通过')
        u['sh000300']['bars']=u['sh000300']['bars'][:-1]
        r=e.analyze(u['sh600001'],u)
        self.assertFalse(r['benchmark_aligned']);self.assertIn('同日基准数据',r['missing'])
        self.assertNotEqual(r['result']['status'],'RESEARCH_SIGNAL')

    def test_csv_validation_cutoff_and_future(self):
        stream=io.StringIO();writer=csv.DictWriter(stream,fieldnames=list(series()[0]));writer.writeheader();writer.writerows(series())
        self.assertEqual(len(e.csv_bars(stream.getvalue(),'2025-05-10')),130)
        with self.assertRaises(ValueError):e.csv_bars(stream.getvalue(),'2099-01-01')
        with self.assertRaises(ValueError):e.csv_bars(stream.getvalue(),'2025-05-12')
        with self.assertRaises(ValueError):e.csv_bars('date,open,high,low,close,volume\n2025-01-01,10,9,8,10,1','2025-01-01')

    def test_partial_exit_includes_fees_and_fx(self):
        t=trade();l=e.ledger(t)
        self.assertEqual(l['quantity'],60);self.assertAlmostEqual(l['avg_cost_quote'],10.1)
        self.assertAlmostEqual(l['realized_quote'],72);self.assertAlmostEqual(l['realized_base'],69.56)
        self.assertFalse(l['closed']);self.assertIsNone(l['net_r'])
        t['fills'].append(dict(date='2025-01-03',side='sell',quantity=60,price=11,fee=6,fx=.92))
        l=e.ledger(t);self.assertTrue(l['closed']);self.assertAlmostEqual(l['realized_base'],125.84)
        self.assertAlmostEqual(l['net_r'],1.2584)

    def test_oversell_noninteger_and_out_of_order_rejected(self):
        for attr,value in [('quantity',101),('quantity',.5),('date','2024-01-01')]:
            t=trade();t['fills'][-1][attr]=value
            with self.subTest(attr=attr,value=value),self.assertRaises(ValueError):e.ledger(t)

    def test_real_paper_open_and_memory_not_mixed(self):
        t=trade();p=trade('paper');p['fills'][-1]['quantity']=100
        ts=[e.review_trade(t),e.review_trade(p)]
        self.assertEqual(e.stats(ts,'real')['closed_count'],0)
        self.assertEqual(e.stats(ts,'paper')['closed_count'],1)
        self.assertIsNone(e.stats(ts,'real')['win_rate'])

    def test_pending_exit_does_not_fabricate_fill(self):
        u=fixture_universe();t=trade();t.update(symbol='sh600001',initial_stop=15.5,buffer=.5)
        t['fills']=[dict(date='2025-05-10',side='buy',quantity=100,price=16.45,fee=0,fx=1)]
        before=copy.deepcopy(t['fills']);i=u['sh600001'];i['bars'][-1].update(open=15,high=15.2,low=14.9,close=15.1)
        result=e.review_trade(t,i)
        self.assertEqual(result['fills'],before);self.assertFalse(result['ledger']['closed'])
        self.assertNotEqual(result['trail']['status'],'HOLD_RESEARCH')

    def test_replay_is_only_historical_signals(self):
        u=fixture_universe();r=e.replay(u['sh600001'],u)
        self.assertTrue(r['signals']);self.assertNotIn('returns',r)
        self.assertEqual(r['signals'][-1]['date'],'2025-05-11')

    def test_changed_exposure_cannot_keep_comparable_r(self):
        t=trade();t['fills'].insert(1,dict(date='2025-01-01',side='buy',quantity=50,price=8,fee=1,fx=.9))
        t['fills'][-1]['quantity']=150
        self.assertTrue(e.ledger(t)['closed']);self.assertIsNone(e.ledger(t)['net_r'])

    def test_pause_requires_five_sessions_and_written_release(self):
        u=fixture_universe();u['hkHSI']=copy.deepcopy(u['sh000300'])
        a={'drawdown_pct':3,'drawdown_episode_start':'2025-05-10'}
        r=e.pause_info([],u,a);self.assertTrue(r['active']);self.assertFalse(r['can_review_release'])
        a['drawdown_episode_start']='2025-05-01'
        r=e.pause_info([],u,a);self.assertTrue(r['can_review_release'])
        a['reviewed_drawdown_key']=r['drawdown_key']
        self.assertFalse(e.pause_info([],u,a)['active'])
        a['pause_active']=True;self.assertTrue(e.pause_info([],u,a)['active'])


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.directory=QA_ROOT/('unit-'+uuid.uuid4().hex[:8])
        self.s=populate(app.Store(self.directory))

    def test_observation_watchlist_is_deduplicated_and_excluded_from_strategy(self):
        payload=dict(id='usNVDA',name='英伟达',source='用户截图')
        app.mutate(self.s,'/api/observation',payload)
        app.mutate(self.s,'/api/observation',{**payload,'name':'英伟达 NVIDIA'})
        state=app.overview(self.s)
        self.assertEqual(len(state['observations']),1)
        self.assertEqual(state['observations'][0]['name'],'英伟达 NVIDIA')
        self.assertNotIn('usNVDA',[i['id'] for i in state['stocks']])
        self.assertIsNone(self.s.get('instrument','usNVDA'))
        with self.assertRaises(ValueError):
            app.mutate(self.s,'/api/instrument',payload)
        with self.assertRaises(ValueError):
            app.mutate(self.s,'/api/observation',{**payload,'id':'us<script>'})
        export_file=self.directory/'observation-backup.json'
        export_file.write_text(json.dumps(self.s.export()),encoding='utf-8')
        restored=self.directory/'restored'
        restore(export_file,restored)
        self.assertEqual(app.overview(app.Store(restored))['observations'],state['observations'])

    def test_bad_mutation_leaves_data_unchanged(self):
        before=self.s.get('instrument','hk01810')
        with self.assertRaises(ValueError):app.mutate(self.s,'/api/import',dict(symbol='hk01810',through='2025-01-01',confirmed=False))
        self.assertEqual(before,self.s.get('instrument','hk01810'))

    def test_persistence_audit_and_proposal_dont_change_engine(self):
        p=app.mutate(self.s,'/api/proposal',dict(title='验证',evidence='10笔记录',change='候选规则',validation='样本外对照'))
        reopened=app.Store(self.directory)
        self.assertEqual(reopened.get('proposal',p['id'])['status'],'待验证')
        self.assertEqual(reopened.export()['version'],e.VERSION)
        self.assertEqual(reopened.audit()[0]['kind'],'proposal')

    def test_trade_correction_preserves_history_and_base_currency_locked(self):
        p=dict(symbol='hk01810',mode='paper',thesis='原始理由',fill=trade()['fills'][0])
        t=app.mutate(self.s,'/api/trade',p)
        c={**trade()['fills'][0], 'id':t['id'],'index':0,'price':11,'reason':'券商流水核对'}
        app.mutate(self.s,'/api/correct',c)
        records=[x for x in self.s.export()['revisions'] if x['kind']=='trade']
        self.assertEqual(len(records),2)
        self.assertEqual(json.loads(records[0]['body'])['fills'][0]['price'],10)
        self.assertEqual(json.loads(records[1]['body'])['thesis'],'原始理由')
        with self.assertRaises(ValueError):app.mutate(self.s,'/api/account',dict(base_currency='HKD',asof='2025-01-01'))

    def test_plan_frozen_and_missing_account_no_position(self):
        for i in fixture_universe().values():self.s.put('instrument',i['id'],i,'QA fixture')
        p=dict(symbol='sh600001',lot=100,roundtrip_cost_per_share_quote=.01,fixed_cost_base=5)
        plan=app.mutate(self.s,'/api/plan',p)
        self.assertIsNone(plan['sizing'])
        snap=copy.deepcopy(plan)
        i=self.s.get('instrument','sh600001');i['bars'][-1]['close']=17.2
        self.s.put('instrument',i['id'],i,'QA new data')
        self.assertEqual(self.s.get('plan',plan['id']),snap)

    def test_full_account_produces_research_sizing(self):
        for i in fixture_universe().values():self.s.put('instrument',i['id'],i,'QA fixture')
        app.mutate(self.s,'/api/account',dict(base_currency='CNY',asof='2025-05-11',equity_base=100000,cash_base=100000,holdings_complete=True,exit_cost_reserve_base=0))
        p=app.mutate(self.s,'/api/plan',dict(symbol='sh600001',lot=100,roundtrip_cost_per_share_quote=.01,fixed_cost_base=5))
        self.assertGreater(p['sizing']['shares'],0);self.assertEqual(p['order_status'],'未下单')
        self.assertLessEqual(p['sizing']['planned_loss_base'],250)

    def test_restore_roundtrip_and_refuse_overwrite(self):
        source=self.directory/'backup.json';source.write_text(json.dumps(self.s.export()),encoding='utf-8')
        target=self.directory/'restored'
        restore(source,target)
        restored=app.Store(target)
        self.assertEqual(restored.list('instrument'),self.s.list('instrument'))
        self.assertEqual(restored.export()['revisions'],self.s.export()['revisions'])
        with self.assertRaises(ValueError):restore(source,target)

    def test_linked_plan_risk_uses_filled_shares_not_plan_max(self):
        for i in fixture_universe().values():self.s.put('instrument',i['id'],i,'QA fixture')
        app.mutate(self.s,'/api/account',dict(base_currency='CNY',asof='2025-05-11',equity_base=1000000,cash_base=1000000,holdings_complete=True,exit_cost_reserve_base=0))
        plan=app.mutate(self.s,'/api/plan',dict(symbol='sh600001',lot=100,roundtrip_cost_per_share_quote=.01,fixed_cost_base=5))
        t=app.mutate(self.s,'/api/trade',dict(symbol='sh600001',mode='paper',thesis='QA',plan_id=plan['id'],fill=dict(date='2025-05-12',side='buy',quantity=100,price=17.2,fee=1,fx=1)))
        expected=100*(17.2-plan['initial_stop']+.01)+5
        self.assertAlmostEqual(t['initial_risk_base'],expected)
        self.assertLess(t['initial_risk_base'],plan['sizing']['planned_loss_base'])
        corrected=app.mutate(self.s,'/api/correct',dict(id=t['id'],index=0,reason='流水数量更正',date='2025-05-12',side='buy',quantity=50,price=17.2,fee=1,fx=1))
        self.assertAlmostEqual(corrected['initial_risk_base'],50*(17.2-plan['initial_stop']+.01)+5)


class HTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        directory=QA_ROOT/('http-'+uuid.uuid4().hex[:8])
        cls.server=app.create_server(0,directory)
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
        cls.url='http://127.0.0.1:'+str(cls.server.server_port)
        cls.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))

    @classmethod
    def tearDownClass(cls):cls.server.shutdown();cls.server.server_close()

    def request(self,path,p=None,headers=None):
        headers=headers or {}
        if p is not None:headers.setdefault('Content-Type','application/json')
        req=urllib.request.Request(self.url+path,data=json.dumps(p).encode() if p is not None else None,headers=headers)
        return self.opener.open(req,timeout=10)

    def test_serves_state_and_export(self):
        state=json.load(self.request('/api/state'));self.assertEqual(len(state['stocks']),6)
        self.assertIn('revisions',json.load(self.request('/api/export')))
        self.assertIn(b'<html',self.request('/').read())

    def test_cross_origin_and_path_escape_blocked(self):
        with self.assertRaises(urllib.error.HTTPError) as c:self.request('/api/proposal',{}, {'Origin':'https://malicious.test'})
        self.assertEqual(c.exception.code,403)
        with self.assertRaises(urllib.error.HTTPError):self.request('/../app.py')
        with self.assertRaises(urllib.error.HTTPError):self.request('/api/state',headers={'Host':'evil.test'})

    def test_refresh_status_route_is_available(self):
        status=json.load(self.request('/api/refresh-status'))
        self.assertIn('status',status)


class RefreshTests(unittest.TestCase):
    def setUp(self):
        self.directory=QA_ROOT/('refresh-'+uuid.uuid4().hex[:8])
        self.s=populate(app.Store(self.directory))

    def test_batch_refresh_commits_each_success_and_keeps_failed_snapshot(self):
        old=self.s.get('instrument','hk01810')
        def fake(sid):
            if sid=='hk01810': raise ValueError('模拟接口失败')
            current=self.s.get('instrument',sid)
            return current['bars'],{'source':'QA','completed_through':current['bars'][-1]['date'],
                                    'fetched_at':'2026-10-17T18:00:00+08:00','adjustment':'bfq',
                                    'adjustment_verified':False,'completed_confirmed':True,
                                    'volume_unit':'QA','amount_unit':'缺失','content_sha256':'qa','status':'自动每日刷新'}
        with patch.object(app,'download_latest_daily',side_effect=fake):
            status=app.refresh_all(self.s,'QA批量刷新')
        self.assertGreater(status['success'],0)
        self.assertGreater(status['failed'],0)
        self.assertEqual(self.s.get('instrument','hk01810'),old)
        self.assertEqual(self.s.get('settings','refresh-status')['failed'],status['failed'])
        self.assertTrue(any(x['status']=='成功' for x in status['records']))

    def test_refresh_lock_prevents_two_batches(self):
        self.s.refresh_lock=threading.Lock();self.s.refresh_lock.acquire()
        status=app.refresh_all(self.s,'QA并发')
        self.assertEqual(status['failed'],1)
        self.s.refresh_lock.release()


if __name__=='__main__':unittest.main()
