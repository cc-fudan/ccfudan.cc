$ErrorActionPreference='Stop'
$task='cc-stock-workbench-daily-refresh'
try {
  Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction Stop
  Write-Output '已删除每日刷新任务；工作台数据与账本保留。'
} catch {
  & schtasks.exe /Delete /F /TN $task | Out-Host
  if ($LASTEXITCODE -ne 0) { throw }
  Write-Output '已删除每日刷新任务；工作台数据与账本保留。'
}
