"""Refresh the local HK/CN research pool after completed market sessions.

This script uses the same deterministic Python code as the workbench and does
not call an LLM. Each instrument is validated and committed independently;
failed requests leave the previous snapshot untouched.
"""
import argparse
import json
from pathlib import Path
import app

parser=argparse.ArgumentParser()
parser.add_argument('--data-dir',type=Path,default=Path(__file__).resolve().parent/'data')
args=parser.parse_args()
store=app.Store(args.data_dir)
print(json.dumps(app.refresh_all(store,'命令行每日刷新'),ensure_ascii=False,indent=2))
