"""V1 research calculations. Standard library only; no execution or return backtest."""
import argparse
import csv
import json
import math
import statistics
import sys
from dataclasses import dataclass
from datetime import date
from decimal import Decimal, ROUND_FLOOR


def finite(value, name, positive=False, nonnegative=False):
    try:
        value = float(value)
    except (ValueError, TypeError, OverflowError) as exc:
        raise ValueError(f"{name}: numeric value required") from exc
    if not math.isfinite(value):
        raise ValueError(f"{name}: finite value required")
    if positive and value <= 0 or nonnegative and value < 0:
        raise ValueError(f"{name}: invalid sign")
    return value


def iso(value):
    d = date.fromisoformat(value)
    if d.isoformat() != value:
        raise ValueError("date must be YYYY-MM-DD")
    return value


@dataclass(frozen=True)
class Bar:
    date: str
    open: float
    high: float
    low: float
    close: float
    volume: float
    amount: float | None = None


def validate(bars):
    if not bars:
        raise ValueError("empty OHLCV")
    previous = ""
    for b in bars:
        iso(b.date)
        if b.date <= previous:
            raise ValueError("dates must be unique and increasing")
        previous = b.date
        for k in ("open", "high", "low", "close"):
            finite(getattr(b, k), k, positive=True)
        finite(b.volume, "volume", nonnegative=True)
        if b.amount is not None:
            finite(b.amount, "amount", nonnegative=True)
        if not (b.low <= min(b.open, b.close) <= max(b.open, b.close) <= b.high):
            raise ValueError(f"OHLC inconsistency: {b.date}")
    return bars


def read_csv(path, completed_through):
    iso(completed_through)
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        raise ValueError("empty CSV")
    required = {"date", "open", "high", "low", "close", "volume"}
    if not required <= rows[0].keys():
        raise ValueError("missing OHLCV columns")
    bars = []
    for r in rows:
        bars.append(Bar(iso(r["date"]), *(finite(r[k], k) for k in
                    ("open", "high", "low", "close", "volume")),
                    finite(r["amount"], "amount") if r.get("amount", "").strip() else None))
    validate(bars)
    bars = [b for b in bars if b.date <= completed_through]
    if not bars or bars[-1].date != completed_through:
        raise ValueError("completed-through must match a supplied trading date")
    return bars


def ma(bars, n, end=None):
    end = len(bars) if end is None else end
    if n <= 0 or end < n:
        return None
    return statistics.fmean(b.close for b in bars[end - n:end])


def atr(bars, n=14):
    if len(bars) < n + 1:
        raise ValueError("ATR needs previous close and complete window")
    return statistics.fmean(max(bars[i].high - bars[i].low,
                               abs(bars[i].high - bars[i-1].close),
                               abs(bars[i].low - bars[i-1].close))
                            for i in range(len(bars)-n, len(bars)))


def deduction(bars, n):
    if len(bars) < n:
        return {"ma": None, "actual_change": None, "next_outgoing": None,
                "unchanged_next_close_estimate": None}
    out = bars[-n].close
    return {"ma": ma(bars, n),
            "actual_change": (bars[-1].close-bars[-n-1].close)/n if len(bars) > n else None,
            "next_outgoing": out,
            "unchanged_next_close_estimate": (bars[-1].close-out)/n}


def signal(bars, benchmark=None, kind="stock"):
    validate(bars)
    if len(bars) < 125:
        raise ValueError("V1 needs at least 125 completed bars")
    if kind not in ("stock", "etf"):
        raise ValueError("kind must be stock or etf")
    base = bars[-21:-1]
    n = max(b.high for b in base)
    d = min(b.low for b in base)
    touches = [i for i, b in enumerate(base) if b.high >= .99*n]
    two_touches = bool(touches and touches[-1]-touches[0] >= 5)
    a = atr(bars)
    bfr = max(.03*n, a)
    stop = n-bfr
    c = bars[-1].close
    volmean = statistics.fmean(b.volume for b in base)
    vr = bars[-1].volume/volmean if volmean > 0 else None
    m60, m120 = ma(bars, 60), ma(bars, 120)
    bench_ok = False
    if benchmark is not None:
        validate(benchmark)
        if len(benchmark) < 65 or benchmark[-1].date != bars[-1].date:
            raise ValueError("benchmark needs 65 bars and matching completed date")
        bench_ok = (benchmark[-1].close > ma(benchmark, 60)
                    and ma(benchmark, 60) > ma(benchmark, 60, len(benchmark)-5))
    checks = {
        "benchmark": bench_ok,
        "trend_order": c > m60 > m120,
        "ma60_rising_5": m60 > ma(bars, 60, len(bars)-5),
        "ma120_not_falling_5": m120 >= ma(bars, 120, len(bars)-5),
        "range_width": (n-d)/n <= .15,
        "separated_touches": two_touches,
        "completed_breakout": c > n+.1*a,
        "volume": bars[-1].volume > 0 and (kind == "etf" or vr is not None and vr >= 1.2),
        "stop_width": stop > 0 and 0 < (c-stop)/c <= .08,
    }
    return {
        "status": "RESEARCH_SIGNAL" if all(checks.values()) else "NO_SIGNAL",
        "date": bars[-1].date, "kind": kind, "checks": checks,
        "failed": [k for k, v in checks.items() if not v],
        "N": n, "D": d, "base_start": base[0].date, "base_end": base[-1].date,
        "touch_dates": [base[i].date for i in touches], "width": (n-d)/n,
        "close": c, "atr14_simple": a, "volume_ratio": vr,
        "buffer": bfr, "initial_stop": stop,
        "entry_max_theoretical": min(c+.5*a, stop/.92) if stop > 0 else None,
        "ma": {str(k): deduction(bars, k) for k in (60, 120, 250)},
        "order_eligibility": "UNVERIFIED: account, events, liquidity, rules, cooldown, pause",
    }


def size_trade(values):
    positive = ("equity_base", "entry", "stop", "fx", "median_amount20_quote", "lot")
    nonnegative = ("cash_base", "roundtrip_cost_per_share_quote", "fixed_cost_base",
                   "existing_gross_base", "existing_stop_risk_base",
                   "group_gross_base", "group_stop_risk_base")
    p = {}
    for k in positive+nonnegative:
        if k not in values:
            raise ValueError(f"missing {k}")
        finite(values[k], k, positive=k in positive, nonnegative=k in nonnegative)
        p[k] = Decimal(str(values[k]))
    if p["lot"] != p["lot"].to_integral_value():
        raise ValueError("lot must be an integer")
    e, s, fx, nav = (p[k] for k in ("entry", "stop", "fx", "equity_base"))
    if s >= e or (e-s)/e > Decimal(".08"):
        raise ValueError("stop must be below entry and within V1 8 percent width")
    if p["group_gross_base"] > p["existing_gross_base"] or p["group_stop_risk_base"] > p["existing_stop_risk_base"]:
        raise ValueError("group exposure/risk cannot exceed total")
    f, cost = p["fixed_cost_base"], p["roundtrip_cost_per_share_quote"]
    unitrisk = (e-s+cost)*fx
    unitcash = (e+cost)*fx
    caps = {
        "single_risk": (nav*Decimal(".0025")-f)/unitrisk,
        "portfolio_risk": (nav*Decimal(".01")-p["existing_stop_risk_base"]-f)/unitrisk,
        "group_risk": (nav*Decimal(".005")-p["group_stop_risk_base"]-f)/unitrisk,
        "single_value": nav*Decimal(".10")/(e*fx),
        "portfolio_value": (nav*Decimal(".40")-p["existing_gross_base"])/(e*fx),
        "group_value": (nav*Decimal(".20")-p["group_gross_base"])/(e*fx),
        "cash": (p["cash_base"]-f)/unitcash,
        "liquidity": p["median_amount20_quote"]*Decimal(".005")/e,
    }
    cap = max(Decimal(0), min(caps.values()))
    q = int((cap/p["lot"]).to_integral_value(rounding=ROUND_FLOOR)*p["lot"])
    planned = Decimal(q)*unitrisk+f if q else Decimal(0)
    stress = Decimal(q)*(e-min(s, Decimal(".85")*e)+cost)*fx+f if q else Decimal(0)
    return {"status": "ILLUSTRATIVE_SIZE" if q else "SKIP_ZERO_SIZE",
            "shares": q, "lots": q//int(p["lot"]), "binding_cap": min(caps, key=caps.get),
            "caps_shares": {k: float(v) for k, v in caps.items()},
            "planned_loss_base": float(planned), "position_value_base": float(q*e*fx),
            "cash_reserved_base": float(q*unitcash+f) if q else 0,
            "stress_loss_15pct_base": float(stress),
            "unlevered_total_loss_base": float(q*unitcash+f) if q else 0,
            "requires": "verified tick, lot, costs, FX, events, account and execution rules"}


def targets(neckline, bottom):
    n = finite(neckline, "neckline", positive=True)
    l = finite(bottom, "bottom", positive=True)
    if l >= n:
        raise ValueError("bottom must be below neckline")
    a = [n+k*(n-l) for k in (1, 2, 3)]
    try:
        g = [n*(n/l)**k for k in (1, 2, 3)]
    except OverflowError as exc:
        raise ValueError("target exceeds finite numeric range") from exc
    if not all(math.isfinite(v) for v in a+g):
        raise ValueError("target exceeds finite numeric range")
    return {"arithmetic": a, "logarithmic": g, "probability": None,
            "scope": "horizontal bottom illustration; not flag targets or V1 exit triggers"}


def trail(bars, entry_date, entry, initial_stop, buffer):
    validate(bars)
    e = finite(entry, "entry", positive=True)
    s = finite(initial_stop, "initial_stop", positive=True)
    s0 = s
    bfr = finite(buffer, "buffer", positive=True)
    if s >= e:
        raise ValueError("initial stop must be below entry")
    try:
        start = next(i for i, b in enumerate(bars) if b.date == iso(entry_date))
    except StopIteration as exc:
        raise ValueError("entry date not supplied") from exc
    if start < 59:
        raise ValueError("need 60 bars including entry date for MA60")
    if not bars[start].low <= e <= bars[start].high:
        raise ValueError("entry outside entry-day range")
    highclose, below = 0, 0
    records = []
    for i in range(start, len(bars)):
        bar = bars[i]
        held = i-start+1
        row = {"date": bar.date, "held": held, "effective_stop": s,
               "confirmed_pivot_date": None, "next_stop": s,
               "max_close": highclose, "below_ma60_count": below, "reason": None}
        if i > start and bar.open <= s:
            row.update(reason="OPEN_STOP", status="EXIT_REQUIRED_AT_OPEN", knowledge_at="OPEN")
            records.append(row)
            break
        highclose = max(highclose, bar.close)
        below = below+1 if bar.close < ma(bars, 60, i+1) else 0
        row.update(max_close=highclose, below_ma60_count=below, knowledge_at="CLOSE")
        reason = None
        if bar.close <= s:
            reason = "CLOSE_STOP"
        elif below >= 2:
            reason = "TWO_CLOSES_BELOW_MA60"
        elif held >= 20 and highclose < e+(e-s0):
            reason = "NO_PROGRESS_20"
        elif held >= 60:
            reason = "MAX_HOLD_60"
        if reason:
            row["reason"] = reason
            row["status"] = "EXIT_REQUIRED_AT_OPEN" if reason == "OPEN_STOP" else "EXIT_REQUIRED_NEXT_SESSION"
            records.append(row)
            break
        j = i-2
        if j > start and j >= 2 and all(bars[j].low < bars[k].low for k in (j-2, j-1, j+1, j+2)):
            row["confirmed_pivot_date"] = bars[j].date
            row["next_stop"] = max(s, bars[j].low-bfr)
        row["status"] = "HOLD_RESEARCH"
        records.append(row)
        s = row["next_stop"]
    return {"records": records, "status": records[-1]["status"],
            "fills": "not simulated; exit-required is an uncompleted task"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("signal")
    p.add_argument("--csv", required=True)
    p.add_argument("--benchmark")
    p.add_argument("--kind", choices=("stock", "etf"), default="stock")
    p.add_argument("--completed-through", required=True)
    p = sub.add_parser("size")
    p.add_argument("--input", required=True)
    p = sub.add_parser("targets")
    p.add_argument("--neckline", required=True, type=float)
    p.add_argument("--bottom", required=True, type=float)
    p = sub.add_parser("trail")
    p.add_argument("--csv", required=True)
    p.add_argument("--completed-through", required=True)
    p.add_argument("--entry-date", required=True)
    for k in ("entry", "initial-stop", "buffer"):
        p.add_argument("--"+k, required=True, type=float)
    a = parser.parse_args()
    try:
        if a.command == "signal":
            bars = read_csv(a.csv, a.completed_through)
            bench = read_csv(a.benchmark, a.completed_through) if a.benchmark else None
            result = signal(bars, bench, a.kind)
        elif a.command == "size":
            with open(a.input, encoding="utf-8-sig") as f:
                result = size_trade(json.load(f))
        elif a.command == "targets":
            result = targets(a.neckline, a.bottom)
        else:
            result = trail(read_csv(a.csv, a.completed_through), a.entry_date,
                           a.entry, a.initial_stop, a.buffer)
        print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    except (ValueError, TypeError, KeyError, OSError, ArithmeticError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False))
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
