"""Local research and accounting. Execution remains a recorded human action."""
import csv
import hashlib
import io
import json
import re
import statistics
from datetime import date, datetime, timedelta, timezone
from strategy import trading_math as mathv1

VERSION = '趋势研究 V1.0 · 日线顺势整理突破'
CHECKS = {
    'benchmark': '基准趋势', 'trend_order': '收盘 > MA60 > MA120',
    'ma60_rising_5': 'MA60 较5日前上行', 'ma120_not_falling_5': 'MA120 不下行',
    'range_width': '整理宽度 ≤15%', 'separated_touches': '两次上沿接触间隔 ≥5日',
    'completed_breakout': '收盘确认突破 +0.1ATR', 'volume': '股票量比 ≥1.2 / ETF有成交',
    'stop_width': '初始风险宽度 ≤8%',
}
EXIT_LABELS = {'OPEN_STOP': '开盘失效：最早可交易时尝试退出', 'CLOSE_STOP': '收盘失效：下一交易日尝试退出',
    'TWO_CLOSES_BELOW_MA60': '连续两日低于MA60', 'NO_PROGRESS_20': '持有20日未达过1价格R', 'MAX_HOLD_60': '60日持有到期'}

def now():
    return datetime.now(timezone(timedelta(hours=8))).isoformat(timespec='seconds')

def num(x, name, positive=False, nonnegative=False):
    return mathv1.finite(x, name, positive, nonnegative)

def text(x, name, limit=2000, required=True):
    s = str(x or '').strip()
    if required and not s:
        raise ValueError(name + '不能为空')
    if len(s) > limit:
        raise ValueError(name + '过长')
    return s

def symbol(x):
    if not re.fullmatch(r'(?:hk\d{5}|(?:sh|sz)\d{6}|hkHSI|hkHSTECH)', str(x)):
        raise ValueError('代码格式：hk01810 / sh600519 / sz000001 / hkHSI / hkHSTECH')
    return x

def bars_of(instrument, cutoff=None):
    return [mathv1.Bar(**{k: row.get(k) for k in ('date','open','high','low','close','volume','amount')})
            for row in instrument.get('bars', []) if cutoff is None or row['date'] <= cutoff]


def observation_input(p):
    sid = text(p.get('id'), '观察代码', 20)
    if not re.fullmatch(r'us[A-Z][A-Z0-9.]{0,11}', sid):
        raise ValueError('美股观察代码格式：usTSM / usNVDA；仅保存自选，不参与V1交易计算')
    return {'id':sid, 'name':text(p.get('name'), '名称', 60), 'market':'US',
            'currency':'USD', 'kind':'stock', 'observation_only':True,
            'source':text(p.get('source','用户添加'), '来源', 300),
            'status':'仅观察 · 暂未接入美股行情与交易规则'}

def csv_bars(raw, through):
    mathv1.iso(through)
    if through > now()[:10]:
        raise ValueError('截止日不能在未来')
    rows = list(csv.DictReader(io.StringIO(raw.lstrip('\ufeff'))))
    if not rows or len(rows) > 10000:
        raise ValueError('CSV须包含1–10000行')
    if not {'date','open','high','low','close','volume'} <= rows[0].keys():
        raise ValueError('CSV缺少 date,open,high,low,close,volume')
    parsed = []
    for r in rows:
        parsed.append(mathv1.Bar(mathv1.iso(r['date']), *(num(r[k], k) for k in ('open','high','low','close','volume')),
                                num(r['amount'],'amount') if r.get('amount','').strip() else None))
    mathv1.validate(parsed)
    parsed = [b for b in parsed if b.date <= through]
    if not parsed or parsed[-1].date != through:
        raise ValueError('截止日必须是CSV中存在的交易日')
    return [b.__dict__ for b in parsed]

def instrument_input(p, existing=None):
    i = dict(existing or {})
    sid = symbol(p.get('id'))
    kind = p.get('kind', 'stock')
    if kind not in ('stock','etf','index'):
        raise ValueError('类型只能为stock/etf/index')
    if sid.startswith(('sh688','sh689','sh8','sz8')) and kind != 'index':
        raise ValueError('V1暂不覆盖该板块')
    benchmark = p.get('benchmark','hkHSI' if sid.startswith('hk') else 'sh000300')
    symbol(benchmark)
    i.update(id=sid, name=text(p.get('name'), '名称', 60), kind=kind,
             market='HK' if sid.startswith('hk') else 'CN', currency='HKD' if sid.startswith('hk') else 'CNY',
             benchmark=benchmark, group=text(p.get('group','未分类'), '风险组', 60),
             bars=i.get('bars',[]), meta=i.get('meta',{}))
    return i

def market_state(i):
    b = bars_of(i)
    result = {'id':i['id'],'name':i['name'],'market':i['market'],'count':len(b),'meta':i.get('meta',{})}
    if len(b) < 65:
        return {**result,'regime':'待数据','close':b[-1].close if b else None,'date':b[-1].date if b else None,'change_pct':None}
    m = mathv1.ma(b,60)
    rising = m > mathv1.ma(b,60,len(b)-5)
    return {**result,'date':b[-1].date,'close':b[-1].close,'change_pct':(b[-1].close/b[-2].close-1)*100,
            'ma60':m,'ma120':mathv1.ma(b,120),'ma60_rising':rising,
            'regime':'允许研究新仓' if b[-1].close > m and rising else '暂停该基准下新仓',
            'distance_ma60_pct':(b[-1].close/m-1)*100}

def analyze(i, universe):
    b = bars_of(i)
    row = {k:i.get(k) for k in ('id','name','market','kind','currency','benchmark','group')}
    row.update(meta=i.get('meta',{}), count=len(b), date=b[-1].date if b else None,
               close=b[-1].close if b else None, version=VERSION, result=None, passed=0, total=9)
    if len(b) < 125:
        return {**row,'state':'待数据','advice':'补齐至少125根已收盘日线，再评估入场。','missing':['行情样本不足']}
    bench_i = universe.get(i['benchmark'])
    bench = bars_of(bench_i, b[-1].date) if bench_i else []
    aligned = len(bench) >= 65 and bench[-1].date == b[-1].date
    r = mathv1.signal(b, bench if aligned else None, i['kind'] if i['kind'] != 'index' else 'etf')
    missing = []
    if not aligned:
        missing.append('同日基准数据')
    if not i.get('meta',{}).get('completed_confirmed'):
        missing.append('已收盘状态确认')
    if not i.get('meta',{}).get('adjustment_verified'):
        missing.append('复权与公司行动核对')
    missing += ['近期事件日历','品种交易资料卡','次日盘口与可成交性']
    passed = sum(r['checks'].values())
    candidate = r['status'] == 'RESEARCH_SIGNAL'
    advice = ('已满足价格条件，保存候选计划；核对事件、资金和次日价格后再决定。' if candidate else
              '等待新的完整信号；本次未通过：'+'、'.join(CHECKS[k] for k in r['failed'])+'。')
    return {**row,'state':'价格条件通过' if candidate else '继续观察','advice':advice,'result':r,
            'passed':passed,'missing':missing,'change_pct':(b[-1].close/b[-2].close-1)*100,
            'benchmark_aligned':aligned}

def chart_data(i):
    b = bars_of(i)
    return [{**x.__dict__,**{'ma'+str(n):mathv1.ma(b,n,j+1) for n in (20,60,120,250)}} for j,x in enumerate(b)]

def ledger(trade):
    qty = 0
    cost_quote = cost_base = realized_quote = realized_base = buys_quote = fees_quote = 0.0
    rows = []
    first_buy = None
    previous = ''
    fills = trade.get('fills',[])
    for idx,f in enumerate(fills):
        day = mathv1.iso(f['date'])
        if day < previous:
            raise ValueError('成交必须按日期顺序记录；同日按录入顺序')
        previous = day
        q = num(f['quantity'],'股数',positive=True)
        if not q.is_integer():
            raise ValueError('股数须为整数')
        p = num(f['price'],'成交价',positive=True)
        fee = num(f['fee'],'费用',nonnegative=True)
        fx = num(f['fx'],'成交汇率',positive=True)
        side = f['side']
        if side == 'buy':
            if any(x['side']=='sell' for x in fills[:idx]):
                raise ValueError('一轮交易卖出后再买入须另建交易编号')
            qty += q
            cost_quote += q*p+fee
            cost_base += (q*p+fee)*fx
            buys_quote += q*p+fee
            first_buy = first_buy or day
        elif side == 'sell':
            if q > qty:
                raise ValueError('卖出股数超过真实剩余持仓')
            allocated = cost_quote*q/qty
            allocated_base = cost_base*q/qty
            realized_quote += q*p-fee-allocated
            realized_base += (q*p-fee)*fx-allocated_base
            cost_quote -= allocated
            cost_base -= allocated_base
            qty -= q
        else:
            raise ValueError('成交方向只能buy/sell')
        fees_quote += fee
        rows.append({'remaining':qty,'cost_quote':cost_quote,'realized_quote':realized_quote})
    closed = bool(fills) and qty == 0
    risk = trade.get('initial_risk_base')
    buys=sum(f['side']=='buy' for f in fills)
    if buys>1 or (fills and trade.get('initial_stop') and trade['initial_stop']>=fills[0]['price']):
        risk=None  # an invalid initial stop or changed exposure invalidates comparable initial R
    return {'quantity':int(qty),'remaining_cost_quote':cost_quote,'remaining_cost_base':cost_base,
            'avg_cost_quote':cost_quote/qty if qty else None,'realized_quote':realized_quote,
            'realized_base':realized_base,'buy_cash_quote':buys_quote,'fees_quote':fees_quote,
            'closed':closed,'entry_date':first_buy,'closed_date':fills[-1]['date'] if closed else None,
            'net_r':realized_base/risk if closed and risk else None,'fill_count':len(fills),
            'averaging':buys>1}

def review_trade(trade, instrument=None, account=None):
    l = ledger(trade)
    notes = []
    if l['averaging']:
        notes.append('出现多次买入：V1禁止加仓；请区分同一委托分笔成交与后续追加。本版暂不计算该轮净R和自动保护价，须人工核对。')
    if trade.get('initial_stop') and trade['fills'] and trade['initial_stop']>=trade['fills'][0]['price']:
        notes.append('所填初始失效价不低于买入价；保留实际成交，初始风险与净R无法验证。')
    if not trade.get('initial_stop'):
        notes.append('未记录买前失效价，无法核对初始风险与退出纪律。')
    if not trade.get('plan_id'):
        notes.append('未关联买前计划；本条保留实际结果，入场合规性待核。')
    if trade.get('adherence') == 'no':
        notes.append('已登记纪律偏离：盈利不能消除过程偏离，亏损也需核对原因。')
    if l['closed'] and l['realized_base']>0 and notes:
        notes.append('结果盈利；过程问题仍保留，避免将救仓盈利当成系统优势。')
    trail = None
    if not l['closed'] and instrument and trade.get('initial_stop') and trade.get('buffer') and not l['averaging']:
        try:
            trail = mathv1.trail(bars_of(instrument), l['entry_date'], trade['fills'][0]['price'],
                                 trade['initial_stop'],trade['buffer'])
            if trail['status'] != 'HOLD_RESEARCH':
                notes.append(EXIT_LABELS[trail['records'][-1]['reason']]+'；待记录真实成交，原任务不自动撤销。')
        except ValueError as e:
            notes.append('持仓规则检查等待数据：'+str(e))
    if not l['closed']:
        notes.append('持仓结果未完成，不计入已平仓胜率。')
    return {**trade,'ledger':l,'review_notes':notes,'trail':trail}

def trade_input(p, instruments):
    sid = symbol(p.get('symbol'))
    if sid not in instruments:
        raise ValueError('先添加该标的到研究池')
    mode = p.get('mode')
    if mode not in ('paper','real'):
        raise ValueError('请选择模拟或实战')
    adherence = p.get('adherence','unknown')
    if adherence not in ('yes','no','unknown'):
        raise ValueError('无效纪律状态')
    t = {'symbol':sid,'name':instruments[sid]['name'],'currency':instruments[sid]['currency'],
         'mode':mode,'thesis':text(p.get('thesis'),'交易理由',2000),
         'notes':text(p.get('notes'),'复盘笔记',4000,False),'adherence':adherence,
         'plan_id':text(p.get('plan_id'),'计划编号',80,False),'version':VERSION,
         'created_at':now(),'fills':[]}
    for key in ('initial_stop','buffer','initial_risk_base'):
        t[key] = num(p[key],key,positive=True) if p.get(key) not in ('',None) else None
    return t

def fill_input(p, currency, base_currency):
    day = mathv1.iso(p['date'])
    if day > now()[:10]:
        raise ValueError('真实成交日期不能在未来')
    fx = num(p.get('fx'),'成交汇率',positive=True)
    if currency == base_currency and abs(fx-1)>1e-9:
        raise ValueError('成交币种与本位币相同，汇率必须为1')
    return {'date':day,'side':p['side'],'quantity':num(p['quantity'],'股数',positive=True),
            'price':num(p['price'],'价格',positive=True),'fee':num(p['fee'],'费用',nonnegative=True),
            'fx':fx,'recorded_at':now(),'evidence':text(p.get('evidence'),'成交来源',500,False)}

def stats(trades, mode):
    subset = [t for t in trades if t['mode']==mode]
    closed = sorted([t for t in subset if t['ledger']['closed']],key=lambda t:t['ledger']['closed_date'])
    pnl = [t['ledger']['realized_base'] for t in closed]
    rs = [t['ledger']['net_r'] for t in closed if t['ledger']['net_r'] is not None]
    assessed = [t for t in closed if t['adherence'] in ('yes','no')]
    return {'mode':mode,'closed_count':len(closed),'open_count':sum(bool(t['fills']) and not t['ledger']['closed'] for t in subset),
            'closed_pnl_base':sum(pnl),'win_rate':sum(p>0 for p in pnl)/len(pnl) if pnl else None,
            'mean_r':statistics.fmean(rs) if rs else None,'r_sample':len(rs),
            'adherence':sum(t['adherence']=='yes' for t in assessed)/len(assessed) if assessed else None,
            'assessed_count':len(assessed),'last5_loss_pause':len(pnl)>=5 and sum(x<0 for x in pnl[-5:])>=3}

def exposures(trades, instruments, account, group):
    totals = {'existing_gross_base':0,'existing_stop_risk_base':0,'group_gross_base':0,'group_stop_risk_base':0}
    missing = []
    count = 0
    for t in trades:
        if t['mode']!='real' or t['ledger']['closed'] or not t['fills']:
            continue
        count += 1
        i = instruments[t['symbol']]
        b = bars_of(i)
        fx = 1 if i['currency']==account.get('base_currency','CNY') else account.get('fx_'+i['currency'].lower())
        stop = t['trail']['records'][-1]['next_stop'] if t.get('trail') else t.get('initial_stop')
        if not b or b[-1].date < max(t['fills'][-1]['date'],account.get('asof') or '') or not fx or not stop:
            missing.append(i['name']+'持仓估值/止损/汇率未齐')
            continue
        # An unfilled exit task remains economically open; use the last effective stop.
        q = t['ledger']['quantity']
        value = q*b[-1].close*fx
        exit_cost = account.get('exit_cost_reserve_base')
        if exit_cost is None:
            missing.append('现持仓剩余退出成本预留未填')
        risk = q*max(b[-1].close-stop,0)*fx
        totals['existing_gross_base'] += value
        totals['existing_stop_risk_base'] += risk
        if i.get('group','未分类') == group:
            totals['group_gross_base'] += value
            totals['group_stop_risk_base'] += risk
    if count and account.get('exit_cost_reserve_base') is not None:
        reserve = account['exit_cost_reserve_base']
        totals['existing_stop_risk_base'] += reserve
        totals['group_stop_risk_base'] += reserve  # conservative allocation to the candidate group
    return totals, missing, count


def pause_info(trades, instruments, account):
    closed=sorted([t for t in trades if t['mode']=='real' and t['ledger']['closed']],key=lambda t:t['ledger']['closed_date'])
    last=closed[-5:]
    loss_key=digest([(t.get('id'),t['ledger']['closed_date'],t['ledger']['realized_base']) for t in last]) if len(last)==5 and sum(t['ledger']['realized_base']<0 for t in last)>=3 else ''
    dd_key=(account.get('drawdown_episode_start') or account.get('asof') or now()[:10]) if account.get('drawdown_pct',0)>=3 else ''
    dates=[];reasons=[]
    if loss_key and account.get('reviewed_loss_key')!=loss_key:
        reasons.append('最近5笔至少3笔亏损');dates.append(last[-1]['ledger']['closed_date'])
    if dd_key and account.get('reviewed_drawdown_key')!=dd_key:
        reasons.append('账户回撤达到3%');dates.append(dd_key)
    start=max(dates) if dates else None
    calendars=[bars_of(instruments[s]) for s in ('hkHSI','sh000300') if s in instruments]
    elapsed=min((sum(b.date>start for b in cal) for cal in calendars),default=0) if start else 0
    if len(calendars)<2:elapsed=0
    return {'active':bool(reasons) or account.get('pause_active',False),'reasons':reasons,
            'manual':account.get('pause_active',False),'since':start,'elapsed_sessions':elapsed,
            'can_review_release':bool(reasons) and elapsed>=5,
            'loss_key':loss_key,'drawdown_key':dd_key,
            'calendar_rule':'恒指与沪深300已导入交易日分别计数，取较少值；至少5日且书面复核'}

def plan(p, instruments, trades, account):
    sid = symbol(p['symbol'])
    if sid not in instruments or instruments[sid]['kind']=='index':
        raise ValueError('请选择普通股票或ETF')
    a = analyze(instruments[sid], instruments)
    if not a['result'] or a['result']['status']!='RESEARCH_SIGNAL':
        raise ValueError('当前未满足V1价格条件，保留观察；不能生成入场计划')
    r = a['result']
    missing = list(a['missing'])
    values, portfolio_missing, count = exposures(trades, instruments, account, instruments[sid]['group'])
    missing += portfolio_missing
    sizing = None
    if count >= 4:
        missing.append('已有4个实战持仓，禁止新增')
    if any(t['symbol']==sid and t['mode']=='real' and not t['ledger']['closed'] for t in trades):
        missing.append('已有同标的持仓，V1不加仓')
    for t in trades:
        if t['mode']=='real' and not t['ledger']['closed'] and t.get('trail') and t['trail']['status']!='HOLD_RESEARCH':
            missing.append('现持仓退出任务待成交，暂停新增')
        if t['symbol']==sid and t['mode']=='real' and t['ledger']['closed']:
            days = sum(b['date']>t['ledger']['closed_date'] for b in instruments[sid]['bars'])
            if days < 5:
                missing.append('同标的退出后不足5个交易日')
    if pause_info(trades,instruments,account)['active']:
        missing.append('账户暂停新增状态：须完成书面复核')
    for field in ('equity_base','cash_base'):
        if account.get(field) is None:
            missing.append('账户'+field+'未填写')
    fx = 1 if instruments[sid]['currency']==account.get('base_currency','CNY') else account.get('fx_'+instruments[sid]['currency'].lower())
    if not fx:
        missing.append('当前折算汇率未填')
    b = bars_of(instruments[sid])[-21:-1]
    amounts = [x.amount for x in b]
    amount = statistics.median(amounts) if all(x is not None and x>0 for x in amounts) else None
    amount = amount or (num(p['median_amount20_quote'],'20日成交额中位数',positive=True) if p.get('median_amount20_quote') else None)
    lot = num(p['lot'],'每手股数',positive=True) if p.get('lot') else None
    if not amount:
        missing.append('此前20日成交额中位数待核')
    if not lot:
        missing.append('合法整手股数待核')
    cost = num(p.get('roundtrip_cost_per_share_quote'),'每股成本',nonnegative=True)
    fixed = num(p.get('fixed_cost_base'),'固定成本',nonnegative=True)
    if account.get('equity_base') and account.get('cash_base') is not None and fx and amount and lot and not portfolio_missing:
        values.update(equity_base=account['equity_base'],cash_base=account['cash_base'],
                      entry=r['entry_max_theoretical'],stop=r['initial_stop'],fx=fx,lot=lot,
                      median_amount20_quote=amount,roundtrip_cost_per_share_quote=cost,fixed_cost_base=fixed)
        sizing = mathv1.size_trade(values)
        if count>=4 or any('V1不加仓' in x or '暂停新增' in x or '不足5个交易日' in x for x in missing):
            sizing = {**sizing,'shares':0,'lots':0,'status':'BLOCKED_BY_PORTFOLIO','planned_loss_base':0,'position_value_base':0,
                      'cash_reserved_base':0,'stress_loss_15pct_base':0,'unlevered_total_loss_base':0}
    return {'symbol':sid,'name':a['name'],'version':VERSION,'created_at':now(),'asof':a['date'],
            'state':'候选研究计划','N':r['N'],'initial_stop':r['initial_stop'],'buffer':r['buffer'],
            'entry_max':r['entry_max_theoretical'],'sizing':sizing,'sizing_inputs':values,
            'missing':list(dict.fromkeys(missing)), 'account_snapshot':dict(account),
            'analysis_snapshot':a,'order_status':'未下单',
            'next_action':'下一交易日核对正式开盘、可买报价与合法价位；仅在区间内限价尝试15分钟。'}

def replay(i, universe, lookback=80):
    b = bars_of(i)
    benchmark = universe.get(i['benchmark'])
    if len(b)<125 or not benchmark:
        raise ValueError('需要125根标的行情和基准数据')
    records=[]
    for end in range(max(125,len(b)-lookback+1),len(b)+1):
        cutoff=b[end-1].date
        bench=bars_of(benchmark,cutoff)
        if len(bench)<65 or bench[-1].date!=cutoff:
            continue
        r=mathv1.signal(b[:end],bench,i['kind'])
        if r['status']=='RESEARCH_SIGNAL':
            records.append({'date':cutoff,'close':r['close'],'N':r['N'],'initial_stop':r['initial_stop'],
                            'entry_max':r['entry_max_theoretical'],'status':'历史价格条件通过；未模拟成交'})
    return {'symbol':i['id'],'version':VERSION,'reviewed_bars':min(lookback,len(b)-124),
            'signals':records,'scope':'逐日只用当时数据；当前数据复权版本可能经供应商修订。没有模拟成交、收益或胜率。'}

def proposal_input(p):
    return {'title':text(p.get('title'),'提案标题',100),'evidence':text(p.get('evidence'),'证据',5000),
            'change':text(p.get('change'),'拟修改规则',2000),'validation':text(p.get('validation'),'验证方案',3000),
            'status':'待验证','base_version':VERSION,'created_at':now()}

def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
