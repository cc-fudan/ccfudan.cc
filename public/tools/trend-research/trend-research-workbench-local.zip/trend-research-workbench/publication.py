"""Public-facing notices; informational notices do not change statutory obligations."""
APP_NAME='趋势研究工作台'
APP_VERSION='1.4.0'
NOTICE={
    'version':'2026-10-18',
    'purpose':'用于数据可视化、规则实验与交易记录。输出是确定性条件研究，不构成针对使用者的证券投资建议、收益承诺或交易指令。',
    'risk':'规则未验证盈利优势。行情、指标和候选线可能错误或滞后；跳空、停牌、流动性和汇率风险可能使损失超出止损预算，现金多头也可能损失全部投入本金。',
    'data':'软件许可不包含第三方行情、数据库、商标或其他材料的使用与再分发许可。使用和分发数据前须自行核对权利与服务条款。',
    'privacy':'完整备份包含账户与历史；AI包可能包含本标的持仓摘要。下载后请自行保管，公开仓库不得提交个人数据。',
    'operations':'开源或免责文字不自动解决著作权、投资咨询资质、个人信息或数据许可问题；不得用其替代实际经营模式的合规审查。',
    'liability':'代码按MIT许可证提供，法律不允许排除或限制的责任不因本说明而被排除。'
}


def short_notice():
    return NOTICE['purpose']+' '+NOTICE['risk']
