"""Causal, deterministic structure research. No MA or order-engine dependency.

Geometry is frozen at pivot confirmation. Events use later completed bars only.
These are project heuristics, not a calibrated recognizer or trading strategy.
"""
from copy import deepcopy
from functools import lru_cache
import hashlib
import json
import statistics

VERSION = 'structure-1.0.0'
LABELS = {'candidate':'候选待突破', 'breakout':'收盘已突破，待回测',
          'retest':'已触及回测带，待后日确认', 'held':'后续收盘确认守住',
          'continuation':'守住后继续推进', 'failed':'突破失败',
          'invalidated':'候选已失效', 'expired':'观察期已过'}
TERMINAL = {'failed','invalidated','expired'}
NAMES = {'double_bottom':'双底', 'double_top':'双顶',
         'inverse_hs':'头肩底', 'hs':'头肩顶', 'rectangle':'水平区间',
         'ascending_triangle':'上升三角形', 'descending_triangle':'下降三角形',
         'sym_triangle':'对称三角形'}


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()


def atr(b, end):
    return statistics.fmean(max(b[j].high-b[j].low,abs(b[j].high-b[j-1].close),
                               abs(b[j].low-b[j-1].close)) for j in range(max(1,end-13),end+1))


def point(b, i, field, radius):
    return dict(date=b[i].date,index=i,price=getattr(b[i],field),field=field,
                confirmed_on=b[i+radius].date,confirmed_index=i+radius)


def line(points):
    a,z=points[0],points[-1]
    slope=(z['price']-a['price'])/(z['index']-a['index']) if z['index']!=a['index'] else 0
    return dict(origin=a['index'],price=a['price'],slope=slope,anchors=points)


def level(boundary, index):
    return boundary['price']+boundary['slope']*(index-boundary['origin'])


def preceding(b, start, volatility):
    if start<20:
        return dict(direction='unknown',change_pct=None,note='结构前不足20根，前趋势不可核验')
    before=statistics.fmean(x.close for x in b[start-20:start-15])
    near=statistics.fmean(x.close for x in b[start-5:start])
    delta=near-before
    direction='up' if delta>max(volatility, before*.03) else 'down' if delta< -max(volatility,before*.03) else 'flat'
    return dict(direction=direction,change_pct=(near/before-1)*100,
                note='结构前20根中，最后5根收盘均值与最早5根比较；阈值为3%与1ATR中的较大者')


def geometry(b, pts, radius, family):
    """Return a frozen candidate, or reject geometry/context independently of MAs."""
    known=max(p['confirmed_index'] for p in pts); start=pts[0]['index']; end=pts[-1]['index']
    span=end-start
    if known>=len(b) or span>100 or any(z['index']-a['index']<3 for a,z in zip(pts,pts[1:])):
        return None
    volatility=atr(b,known); tolerance=max(volatility*.4,b[known].close*.006)
    pre=preceding(b,start,volatility); upper=lower=None; direction=0; neck=None
    prices=[p['price'] for p in pts]
    if family in ('double_bottom','double_top'):
        direction=1 if family=='double_bottom' else -1
        expected=['low','high','low'] if direction==1 else ['high','low','high']
        if [p['field'] for p in pts]!=expected or span<8 or pre['direction']!=('down' if direction==1 else 'up'):
            return None
        if abs(prices[0]-prices[2])>max(statistics.fmean([prices[0],prices[2]])*.03,volatility*.5):return None
        depth=direction*(prices[1]-(max(prices[0],prices[2]) if direction==1 else min(prices[0],prices[2])))
        if depth<max(volatility,abs(prices[1])*.015):return None
        neck=line([pts[1]]); height=abs(prices[1]-statistics.fmean([prices[0],prices[2]]))
    elif family in ('inverse_hs','hs'):
        direction=1 if family=='inverse_hs' else -1
        expected=['low','high','low','high','low'] if direction==1 else ['high','low','high','low','high']
        if [p['field'] for p in pts]!=expected or span<16 or pre['direction']!=('down' if direction==1 else 'up'):return None
        shoulders=[prices[0],prices[4]]
        if abs(shoulders[0]-shoulders[1])>max(statistics.fmean(shoulders)*.04,volatility):return None
        if min(direction*(p-prices[2]) for p in shoulders)<max(volatility*.8,abs(prices[2])*.015):return None
        left=pts[2]['index']-start;right=end-pts[2]['index']
        if not .4<=left/right<=2.5:return None
        neck=line([pts[1],pts[3]]);height=direction*(level(neck,pts[2]['index'])-prices[2])
        if height<2*volatility or abs(prices[1]-prices[3])>height*.6:return None
        if any(direction*(level(neck,p['index'])-p['price'])<volatility*.5 for p in (pts[0],pts[4])):return None
    else:
        if span<16:return None
        highs=[p for p in pts if p['field']=='high'];lows=[p for p in pts if p['field']=='low']
        if len(highs)!=3 or len(lows)!=3:return None
        upper=line(highs);lower=line(lows)
        if any(abs(p['price']-level(upper,p['index']))>tolerance for p in highs):return None
        if any(abs(p['price']-level(lower,p['index']))>tolerance for p in lows):return None
        width=level(upper,start)-level(lower,start);last_width=level(upper,known)-level(lower,known)
        if width<2*volatility or last_width<volatility or width/level(upper,start)>.30:return None
        flat=tolerance/span
        us,ls=upper['slope'],lower['slope']
        if abs(us)<=flat and abs(ls)<=flat:
            actual='rectangle'
            if abs(last_width-width)>2*tolerance:return None
        elif last_width<width*.85 and abs(us)<=flat and ls>flat:actual='ascending_triangle'
        elif last_width<width*.85 and us< -flat and abs(ls)<=flat:actual='descending_triangle'
        elif last_width<width*.85 and us< -flat and ls>flat:actual='sym_triangle'
        else:return None
        if family!=actual:return None
        cuts=sum(b[j].close>level(upper,j)+tolerance or b[j].close<level(lower,j)-tolerance for j in range(start,known+1))
        if cuts>max(1,int((known-start+1)*.1)):return None
        height=width
    if neck:
        # A candidate must not be backdated across a breakout that happened before
        # all required pivots were knowable. Such an early move is not our signal.
        if any(direction*(b[j].close-level(neck,j))>max(.1*volatility,.001*abs(level(neck,j))) for j in range(end,known+1)):
            return None
        cuts=sum(min(b[j].open,b[j].close)<level(neck,j)<max(b[j].open,b[j].close) for j in range(start,end+1))
        if cuts>max(1,int(span*.1)):return None
    else:cuts=0
    key=[VERSION,family,radius,[(p['date'],p['field']) for p in pts]]
    record=dict(id='s-'+digest(key)[:16],family=family,name=NAMES[family],radius=radius,
                start_index=start,known_index=known,known_on=b[known].date,anchors=deepcopy(pts),
                upper=upper,lower=lower,neck=neck,expected_direction=direction,direction=0,
                height=height,atr=volatility,tolerance=tolerance,pretrend=pre,neck_body_cuts=cuts,
                expires_index=known+min(60,max(20,span)),state='candidate',events=[],
                evidence=[f'严格左{radius}右{radius}拐点；形成跨度{span}根',f'形成区间颈线穿越实体{cuts}根' if neck else '两侧边界中间接触点误差与收盘越界比例已检查',
                          '反转前趋势与轮廓检查通过' if direction else '上下边界各有3个已确认接触点；未预设突破方向'],
                counterevidence=['阈值为项目实验定义，候选拟合不是胜率；公告、除权和流动性未核验'],
                interpretation=('潜在反转' if direction else '潜在中继' if pre['direction'] in ('up','down') else '区间方向待定'))
    record['events'].append(event(record,b,known,'candidate','轮廓所需拐点首次全部可知'))
    return record


def event(s,b,j,state,reason):
    boundary=s['neck'] or (s['upper'] if s['direction']>=0 else s['lower'])
    return dict(date=b[j].date,index=j,state=state,label=LABELS[state],close=b[j].close,
                boundary=level(boundary,j),reason=reason,provenance='snapshot_reconstruction')


def advance(s,b,j):
    if s['state'] in TERMINAL or j<=s['known_index']:return
    state=s['state']; c=b[j].close; new=None;reason=''
    if state=='candidate':
        if j>s['expires_index'] or (s['upper'] and level(s['upper'],j)<=level(s['lower'],j)):
            new='expired';reason='候选到期或三角边界已相交，停止沿用旧线'
        elif s['neck']:
            n=level(s['neck'],j);buffer=max(.1*s['atr'],abs(n)*.001);direction=s['expected_direction']
            extreme=min(p['price'] for p in s['anchors']) if direction==1 else max(p['price'] for p in s['anchors'])
            if direction*(c-extreme)<-buffer:
                new='invalidated';reason='未突破前收盘越过反转结构极值，候选失效'
            elif direction*(c-n)>buffer:
                new='breakout';s['direction']=direction;reason='所需拐点可知之后，收盘越过本结构颈线及过滤带'
        else:
            up=level(s['upper'],j);down=level(s['lower'],j);buffer=max(.1*s['atr'],abs(c)*.001)
            if c>up+buffer or c<down-buffer:
                s['direction']=1 if c>up+buffer else -1
                new='breakout';reason='收盘越过本结构上边界' if s['direction']==1 else '收盘跌破本结构下边界'
        if new=='breakout':
            s['breakout_index']=j;s['breakout_boundary']=level(s['neck'] or (s['upper'] if s['direction']==1 else s['lower']),j)
            prev=[x.volume for x in b[max(0,j-20):j]]
            s['breakout_volume_ratio']=b[j].volume/statistics.fmean(prev) if prev and statistics.fmean(prev)>0 else None
            if s['breakout_volume_ratio'] is None or s['breakout_volume_ratio']<1.2:
                s['counterevidence'].append('突破日量比不足1.2或不可比；量能只作独立证据，未否定价格事件')
    else:
        boundary=s['neck'] or (s['upper'] if s['direction']==1 else s['lower'])
        n=level(boundary,j);distance=s['direction']*(c-n);buffer=max(.1*s['atr'],abs(n)*.001)
        if n<=0 or distance< -buffer:
            new='failed';reason='突破后收盘回到原边界另一侧，原突破解释失败；旧记录保留'
        elif j-s['breakout_index']>60:
            new='expired';reason='突破观察超过60根，归档；未触达量度位不等于交易盈亏'
        elif state=='breakout' and b[j].low<=n+s['tolerance'] and b[j].high>=n-s['tolerance']:
            new='retest';s['retest_index']=j;reason='后续交易日触及边界容差带；仅凭当日OHLC不宣称先回测后站稳'
        elif state=='retest' and j>s['retest_index'] and distance>buffer:
            new='held';reason='回测日之后的已完成收盘仍在突破一侧，按本定义确认守住'
        elif state=='held' and distance>=s['height']*.5:
            new='continuation';reason='守住后的后续收盘推进超过半个结构高度；不保证量度目标到达'
    if new:
        s['state']=new;s['events'].append(event(s,b,j,new,reason))


def scan(b):
    """Replay chronologically. Every prefix has exactly the same earlier events."""
    if len(b)<25:return []
    found={};swings={2:[],5:[]}
    for j in range(4,len(b)):
        for s in found.values():advance(s,b,j)
        for radius,seq in swings.items():
            i=j-radius
            if i<radius:continue
            around=[k for k in range(i-radius,i+radius+1) if k!=i]
            high=all(b[i].high>b[k].high for k in around)
            low=all(b[i].low<b[k].low for k in around)
            if high==low:continue  # Outside bars do not establish intrabar order.
            p=point(b,i,'high' if high else 'low',radius)
            if seq and seq[-1]['field']==p['field']:
                if (p['price']-seq[-1]['price'])*(1 if high else -1)<=0:continue
                seq[-1]=p
            else:seq.append(p)
            seq[:]=[v for v in seq if i-v['index']<=120]
            for size,families in ((3,('double_bottom','double_top')),(5,('inverse_hs','hs')),
                                  (6,('rectangle','ascending_triangle','descending_triangle','sym_triangle'))):
                if len(seq)<size:continue
                for family in families:
                    s=geometry(b,seq[-size:],radius,family)
                    if s and s['id'] not in found:found[s['id']]=s
    return list(found.values())


@lru_cache(maxsize=48)
def _cached(rows):
    # Importing the Bar value type does not import execution predicates.
    from strategy.trading_math import Bar
    return scan([Bar(*row) for row in rows])


def analyze(b):
    rows=tuple((x.date,x.open,x.high,x.low,x.close,x.volume,x.amount) for x in b)
    patterns=deepcopy(_cached(rows))
    active=[s for s in patterns if s['state'] not in TERMINAL]
    active.sort(key=lambda s:(s['events'][-1]['index'],s['known_index'],s['radius']),reverse=True)
    recent=sorted((s for s in patterns if s['state'] in TERMINAL),key=lambda s:s['events'][-1]['index'],reverse=True)
    selected=(active+recent)[:16]
    for s in selected:
        s['state_label']=LABELS[s['state']]
        endpoint=s['events'][-1]['index'] if s['state'] in TERMINAL else len(b)-1
        s['boundary_asof']=b[endpoint].date
        s['boundary_now']={k:level(s[k],endpoint) for k in ('neck','upper','lower') if s[k]}
        s['failure_now']=(s['boundary_now'].get('neck') or s['boundary_now'].get('upper' if s['direction']>=0 else 'lower'))
        s['target']=None
        if s['direction']:
            n=s['breakout_boundary'];d=s['direction'];height=s['height']
            s['target']={'arithmetic':n+d*height,'basis':'突破日边界加减一倍结构高度；算术观察位，无概率保证'}
    directions={s['direction'] or s['expected_direction'] for s in active}-{0}
    return dict(version=VERSION,primary_id=active[0]['id'] if active else None,
                total=len(patterns),active_count=len(active),patterns=selected,
                conflict=len(directions)>1,
                unsupported=['三重结构','旗形与楔形','菱形','圆弧','复杂复合形态'],
                timing='全部历史事件由当前快照逐日重建，不表示程序在历史当日实际运行过；首次观察时间另记。')


def tracking(instrument, observed_at, previous=None):
    """Private settings snapshot; old generations remain in the revisions table."""
    from strategy.trading_math import Bar
    b=[Bar(**{k:x.get(k) for k in ('date','open','high','low','close','volume','amount')}) for x in instrument.get('bars',[])]
    hashes={x.date:digest(x.__dict__) for x in b};adjustment=(instrument.get('meta') or {}).get('adjustment')
    previous=previous or {};old=previous.get('bar_hashes',{})
    overlap=set(old)&set(hashes)
    revised=any(old[d]!=hashes[d] for d in overlap) or bool(old and previous.get('adjustment')!=adjustment)
    if old and (not b or b[-1].date<previous.get('asof','')):revised=True
    if old and hashes:
        lo=max(min(old),min(hashes));hi=min(max(old),max(hashes))
        if {d for d in old if lo<=d<=hi}!={d for d in hashes if lo<=d<=hi}:revised=True
        if min(hashes)<min(old):revised=True  # Earlier backfill can change context.
    if old and not overlap:revised=True
    changed_version=previous.get('version',VERSION)!=VERSION
    compared=bool(old and not revised and not changed_version and previous.get('asof') in hashes)
    new_candidates=[];new_events=[]
    generation=previous.get('generation',1)+(1 if revised or changed_version else 0)
    report=analyze(b)
    observed=deepcopy(previous.get('first_observed',{})) if not (revised or changed_version) else {}
    # Keep first actual observation times independent from reconstructed event dates.
    all_patterns=deepcopy(_cached(tuple((x.date,x.open,x.high,x.low,x.close,x.volume,x.amount) for x in b)))
    archive=deepcopy(previous.get('archive',{})) if not (revised or changed_version) else {}
    observed_events=deepcopy(previous.get('event_observed',{})) if not (revised or changed_version) else {}
    for s in all_patterns:
        observed.setdefault(s['id'],observed_at)
        old_pattern=archive.get(s['id'])
        if compared:
            if old_pattern is None and s['known_on']>previous['asof']:
                new_candidates.append(dict(id=s['id'],name=s['name'],known_on=s['known_on'],state=LABELS[s['state']]))
            old_events={(ev['date'],ev['state']) for ev in (old_pattern or {}).get('events',[])}
            for ev in s['events']:
                if ev['date']>previous['asof'] and (ev['date'],ev['state']) not in old_events:
                    event_key=s['id']+'/'+ev['date']+'/'+ev['state']
                    new_events.append(dict(id=s['id'],name=s['name'],
                        **{k:ev[k] for k in ('date','state','label','close','boundary','reason')},
                        first_observed_at=observed_events.get(event_key,observed_at)))
        archive[s['id']]=s
        for ev in s['events']:
            observed_events.setdefault(s['id']+'/'+ev['date']+'/'+ev['state'],observed_at)
    return dict(version=VERSION,symbol=instrument['id'],asof=b[-1].date if b else None,
                observed_at=observed_at,generation=generation,bar_hashes=hashes,adjustment=adjustment,
                revision_detected=revised or changed_version,first_observed=observed,event_observed=observed_events,report=report,archive=archive,
                changes_since_previous=dict(compared=compared,from_date=previous.get('asof') if compared else None,to_date=b[-1].date if b else None,
                    new_candidates=new_candidates,new_events=new_events,
                    note='仅列两次实际保存扫描之间新增、且发生日晚于前一快照的事件；回看更早图形不算新发生。' if compared else '首次保存为历史重建起点；尚无可比较的前次真实扫描。'),
                data_change='历史重叠数据或复权口径改变，建立新代；旧代保留于审计备份' if revised else '结构算法版本改变，建立新代；旧代保留于审计备份' if changed_version else '首次扫描或同口径追加/窗口滚动',
                data_sha256=digest(instrument.get('bars',[])))


def cross_validate(report, bullish, bearish, execution):
    rows=[]
    for s in report['patterns']:
        direction=s['direction'] or s['expected_direction']
        ma='支持向上' if bullish else '支持向下' if bearish else '方向未统一'
        if s['state'] in TERMINAL:
            relation='结构已失效/到期'
        elif not s['direction']:
            relation='候选方向与均线冲突，且未突破' if (direction==1 and bearish) or (direction==-1 and bullish) else '尚无方向性突破'
        else:
            relation='同向' if (direction==1 and bullish) or (direction==-1 and bearish) else '冲突' if bullish or bearish else '均线待确认'
        rows.append(dict(id=s['id'],name=s['name'],structure=s['state_label'],ma=ma,relation=relation,
                         execution='V1价格条件齐备，仍须核对执行资料' if execution=='RESEARCH_SIGNAL' else 'V1不允许建立新仓',
                         note='向下结构只提示风险；当前系统仅做多。' if direction==-1 else '结构事件不授予交易权限。'))
    return rows


def chart_lines(report,b):
    output=[]
    primary=next((s for s in report['patterns'] if s['id']==report['primary_id']),None)
    # Show primary by default; alternative lines are available when selected.
    for s in report['patterns']:
        endpoint=s['events'][-1]['index'] if s['state'] in TERMINAL else len(b)-1
        for key in ('neck','upper','lower'):
            boundary=s[key]
            if not boundary:continue
            label={'neck':'颈线','upper':'上边界','lower':'下边界'}[key]
            output.append(dict(id=s['id']+'-'+key,structure_id=s['id'],label=s['name']+' '+label,
                kind='pattern',side='low' if key=='lower' else 'high',
                start_date=b[s['start_index']].date,end_date=b[endpoint].date,
                start_price=level(boundary,s['start_index']),end_price=level(boundary,endpoint),
                anchors=s['anchors'],known_on=s['known_on'],touches=len(boundary['anchors']),
                color='#a18b45' if s is primary else '#8a92ac',status=s['state_label'],
                basis='结构首次可知时冻结边界；后续事件只读取其后的收盘。延长线只供观察，失效或到期后不继续当作有效边界。'))
    return output
