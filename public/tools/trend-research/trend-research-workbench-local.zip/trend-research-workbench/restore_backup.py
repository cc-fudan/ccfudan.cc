"""Restore an exported JSON backup into a NEW directory; never overwrite data."""
import argparse
import json
from pathlib import Path
import app
import engine as e

def restore(source, destination):
    target=Path(destination)
    if target.exists():
        raise ValueError('目标目录必须不存在，避免覆盖现有账本')
    obj=json.loads(Path(source).read_text(encoding='utf-8-sig'))
    if obj.get('format')!='cc-workbench-backup-1':
        raise ValueError('备份格式不匹配')
    data=obj['objects']
    allowed={'instrument','settings','plan','trade','proposal'}
    if set(data)!=allowed:
        raise ValueError('备份对象类型不完整')
    u={i['id']:i for i in data['instrument']}
    for i in u.values():
        e.instrument_input(i)
        if i['bars']: e.mathv1.validate(e.bars_of(i))
    for t in data['trade']:
        if t['symbol'] not in u:raise ValueError('交易标的缺失')
        e.ledger(t)
    for r in obj['revisions']:
        if r['kind'] not in allowed:raise ValueError('历史记录类型错误')
        json.loads(r['body'])
    # Initialize tables, then atomically replace seed content with validated backup.
    store=app.Store(target)
    with store.connect() as db:
        db.execute('DELETE FROM objects')
        db.execute('DELETE FROM revisions')
        for kind,records in data.items():
            for r in records:db.execute('INSERT INTO objects VALUES (?,?,?)',(kind,r['id'],json.dumps(r,ensure_ascii=False,allow_nan=False)))
        for r in obj['revisions']:
            db.execute('INSERT INTO revisions VALUES (?,?,?,?,?,?)',tuple(r[k] for k in ('seq','at','kind','id','reason','body')))
    return store.path

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--file',required=True,type=Path)
    p.add_argument('--data-dir',required=True,type=Path)
    a=p.parse_args()
    print(restore(a.file,a.data_dir))
