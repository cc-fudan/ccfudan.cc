"""cc investment workbench. Local-only decision support; no broker connection."""
import argparse
import json
import mimetypes
import sqlite3
import threading
import time
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import engine as e
import research
import publication
import structures

ROOT = Path(__file__).resolve().parent


class Store:
    def __init__(self, directory):
        Path(directory).mkdir(parents=True, exist_ok=True)
        self.path = Path(directory)/'workbench.sqlite3'
        self.lock = threading.RLock()
        self.refresh_lock = threading.Lock()
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS objects (kind TEXT, id TEXT, body TEXT, PRIMARY KEY(kind,id))')
            db.execute('CREATE TABLE IF NOT EXISTS revisions (seq INTEGER PRIMARY KEY, at TEXT, kind TEXT, id TEXT, reason TEXT, body TEXT)')
        if not self.list('instrument'):
            seed = json.loads((ROOT/'assets'/'bootstrap.json').read_text(encoding='utf-8'))
            for obj in seed['instruments']:
                self.put('instrument', obj['id'], obj, '初始化：已保存行情快照')
        if not self.get('settings','account'):
            self.put('settings','account', {'base_currency':'CNY','equity_base':None,'cash_base':None,
                     'fx_hkd':None,'fx_cny':1,'drawdown_pct':0,'pause_active':False,
                     'exit_cost_reserve_base':None,'holdings_complete':False,'asof':''}, '初始化')
        if not self.get('settings','refresh-preferences'):
            self.put('settings','refresh-preferences',{'enabled':False,'time':'17:10','timezone':'Asia/Shanghai'},'初始化：自动联网刷新默认关闭')

    def connect(self):
        return sqlite3.connect(self.path, timeout=20)

    def get(self, kind, identity):
        with self.connect() as db:
            row=db.execute('SELECT body FROM objects WHERE kind=? AND id=?',(kind,identity)).fetchone()
        return json.loads(row[0]) if row else None

    def list(self, kind):
        with self.connect() as db:
            rows=db.execute('SELECT body FROM objects WHERE kind=? ORDER BY rowid',(kind,)).fetchall()
        return [json.loads(x[0]) for x in rows]

    def put(self, kind, identity, obj, reason):
        obj={**obj,'id':identity}
        body=json.dumps(obj,ensure_ascii=False,allow_nan=False)
        tracked=None
        if kind=='instrument' and obj.get('bars'):
            previous=self.get('settings','structure:'+identity)
            adjustment=(obj.get('meta') or {}).get('adjustment')
            if not previous or previous.get('data_sha256')!=structures.digest(obj['bars']) or previous.get('adjustment')!=adjustment or previous.get('version')!=structures.VERSION:
                tracked=structures.tracking(obj,e.now(),previous)
                tracked['id']='structure:'+identity
        with self.connect() as db:
            db.execute('INSERT OR REPLACE INTO objects VALUES (?,?,?)',(kind,identity,body))
            db.execute('INSERT INTO revisions(at,kind,id,reason,body) VALUES (?,?,?,?,?)',
                       (e.now(),kind,identity,reason,body))
            if tracked:
                payload=json.dumps(tracked,ensure_ascii=False,allow_nan=False)
                db.execute('INSERT OR REPLACE INTO objects VALUES (?,?,?)',('settings',tracked['id'],payload))
                db.execute('INSERT INTO revisions(at,kind,id,reason,body) VALUES (?,?,?,?,?)',
                           (e.now(),'settings',tracked['id'],'结构扫描：'+tracked['data_change'],payload))
        return obj

    def audit(self, limit=100):
        with self.connect() as db:
            rows=db.execute('SELECT seq,at,kind,id,reason FROM revisions ORDER BY seq DESC LIMIT ?',(limit,)).fetchall()
        return [dict(zip(('seq','at','kind','id','reason'),r)) for r in rows]

    def export(self):
        with self.connect() as db:
            rows=db.execute('SELECT seq,at,kind,id,reason,body FROM revisions ORDER BY seq').fetchall()
        return {'format':'cc-workbench-backup-1','exported_at':e.now(),'version':e.VERSION,
                'notice':'私有完整备份含原始历史与账户，不属于开源发布材料。',
                'objects':{k:self.list(k) for k in ('instrument','settings','plan','trade','proposal')},
                'revisions':[dict(zip(('seq','at','kind','id','reason','body'),r)) for r in rows]}


def universe(store):
    return {i['id']:i for i in store.list('instrument')}


def detail_payload(store, sid):
    u=universe(store)
    if sid not in u:
        raise ValueError('标的不存在')
    account=store.get('settings','account')
    # The method report may read existing positions but never writes trades,
    # plans or stops. V1's existing analyzer remains the execution authority.
    selected_trades=[t for t in trades_view(store,u,account) if t['symbol']==sid]
    return {'analysis':e.analyze(u[sid],u),'chart':e.chart_data(u[sid]),
            'research':research.build(u[sid],u,selected_trades,store.get('settings','structure:'+sid))}


def trades_view(store, instruments, account):
    return [e.review_trade(t,instruments.get(t['symbol']),account) for t in store.list('trade') if not t.get('voided')]


def overview(store):
    u=universe(store)
    a=store.get('settings','account')
    ts=trades_view(store,u,a)
    return {'version':e.VERSION,'app_version':publication.APP_VERSION,'server_time':e.now(),'account':a,
            'notice':publication.NOTICE,'refresh_preferences':store.get('settings','refresh-preferences'),
            'markets':[e.market_state(i) for i in u.values() if i['kind']=='index'],
            'stocks':[e.analyze(i,u) for i in u.values() if i['kind']!='index'],
            'observations':(store.get('settings','observations') or {}).get('items',[]),
            'plans':store.list('plan')[::-1], 'trades':ts[::-1],
            'stats':{m:e.stats(ts,m) for m in ('real','paper')},
            'proposals':store.list('proposal')[::-1],'checks':e.CHECKS,'audit':store.audit(30),
            'pause':e.pause_info(ts,u,a),
            'refresh':store.get('settings','refresh-status') or {'status':'尚未刷新'} }


def download_daily(sid, cutoff, confirmed):
    e.symbol(sid)
    e.mathv1.iso(cutoff)
    current=e.now()
    if cutoff > current[:10]:
        raise ValueError('不能请求未来收盘')
    # Conservative guard: never assume the current session is final before 17:00.
    if cutoff == current[:10] and (current[11:16] < '17:00' or not confirmed):
        raise ValueError('今日数据须在北京时间17:00后，并明确确认已收盘；否则选择上一交易日')
    url='https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param='+sid+',day,,,500,bfq'
    request=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
    try:
        # Direct HTTPS: the desktop runtime may inherit a stale local proxy.
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(request,timeout=18) as response:
            raw=response.read(4000000)
        obj=json.loads(raw)
        rows=obj['data'][sid]['day']
        bars=[{'date':r[0],'open':float(r[1]),'close':float(r[2]),'high':float(r[3]),
               'low':float(r[4]),'volume':float(r[5]),'amount':None} for r in rows if r[0]<=cutoff]
        e.mathv1.validate([e.mathv1.Bar(**b) for b in bars])
        if bars[-1]['date'] != cutoff:
            raise ValueError('接口末日与指定已收盘截止日不一致，请检查交易日或改用CSV')
    except (KeyError, TypeError, json.JSONDecodeError) as exc:
        raise ValueError('行情接口格式变化，原数据未改写；请使用CSV导入') from exc
    return bars, {'source':'腾讯财经公开日线接口（非交易所直连）','source_url':url,
                  'fetched_at':e.now(),'adjustment':'bfq / 不复权','adjustment_verified':False,
                  'completed_confirmed':bool(confirmed),'completed_through':cutoff,
                  'volume_unit':'供应商原始口径；未核对单位','amount_unit':'缺失',
                  'content_sha256':e.digest(bars),'status':'在线刷新'}


def download_latest_daily(sid):
    """Fetch latest completed vendor bars without assuming every market traded today."""
    e.symbol(sid)
    url='https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param='+sid+',day,,,500,bfq'
    request=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
    clock=e.now()
    from datetime import date,timedelta
    today=clock[:10] if clock[11:16]>='17:00' else (date.fromisoformat(clock[:10])-timedelta(days=1)).isoformat()
    try:
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(request,timeout=18) as response:
            raw=response.read(4000000)
        obj=json.loads(raw)
        rows=obj['data'][sid]['day']
        rows=[r for r in rows if r[0] <= today]
        bars=[{'date':r[0],'open':float(r[1]),'close':float(r[2]),'high':float(r[3]),
               'low':float(r[4]),'volume':float(r[5]),'amount':None} for r in rows]
        e.mathv1.validate([e.mathv1.Bar(**b) for b in bars])
        if not bars:
            raise ValueError('接口没有返回已完成日线')
    except (KeyError, TypeError, json.JSONDecodeError) as exc:
        raise ValueError('行情接口格式变化，原数据未改写；请稍后重试或使用CSV导入') from exc
    cutoff=bars[-1]['date']
    return bars, {'source':'腾讯财经公开日线接口（非交易所直连）','source_url':url,
                  'fetched_at':e.now(),'adjustment':'bfq / 不复权','adjustment_verified':False,
                  'completed_confirmed':True,'completed_through':cutoff,
                  'volume_unit':'供应商原始口径；未核对单位','amount_unit':'缺失',
                  'content_sha256':e.digest(bars),'status':'自动每日刷新'}


def refresh_all(store, reason='手动批量刷新'):
    """Refresh local HK/CN instruments independently; failures retain old snapshots."""
    lock=getattr(store,'refresh_lock',None)
    if lock is None:
        lock=store.refresh_lock=threading.Lock()
    if not lock.acquire(blocking=False):
        return {'id':'refresh-status','started_at':e.now(),'finished_at':e.now(),'reason':reason,
                'records':[],'success':0,'failed':1,'skipped':0,'error':'已有刷新任务正在运行'}
    try:
        started=e.now(); records=[]
        for item in store.list('instrument'):
            sid=item['id']
            if item.get('market') not in ('HK','CN'):
                records.append({'symbol':sid,'name':item.get('name'),'status':'跳过','reason':'仅观察或未覆盖市场'})
                continue
            try:
                bars,meta=download_latest_daily(sid)
                with store.lock:
                    current=store.get('instrument',sid)
                    if current.get('bars') and bars[-1]['date']<current['bars'][-1]['date']:
                        raise ValueError('供应商末日早于本地快照，保留本地数据')
                    store.put('instrument',sid,{**current,'bars':bars,'meta':meta},reason+'：'+meta['completed_through'])
                records.append({'symbol':sid,'name':item.get('name'),'status':'成功','through':meta['completed_through'],'bars':len(bars)})
            except Exception as exc:
                records.append({'symbol':sid,'name':item.get('name'),'status':'失败','error':str(exc)[:300],
                                'old_through':(item.get('meta') or {}).get('completed_through')})
        status={'id':'refresh-status','started_at':started,'finished_at':e.now(),'reason':reason,
                'records':records,'success':sum(x['status']=='成功' for x in records),
                'failed':sum(x['status']=='失败' for x in records),'skipped':sum(x['status']=='跳过' for x in records)}
        store.put('settings','refresh-status',status,reason+'：批量结果')
        return status
    finally:
        lock.release()


def refresh_worker(server):
    """Local service scheduler: one batch after 17:10 Beijing per calendar day."""
    while not getattr(server,'shutdown_requested',False):
        try:
            now=e.now(); day=now[:10]
            prefs=server.store.get('settings','refresh-preferences') or {}
            latest=server.store.get('settings','refresh-status') or {}
            if prefs.get('enabled') and now[11:16] >= '17:10' and not latest.get('finished_at','').startswith(day):
                refresh_all(server.store,'服务自动每日刷新')
        except Exception as exc:
            server.store.put('settings','refresh-status',{'id':'refresh-status','started_at':e.now(),
                'finished_at':e.now(),'reason':'服务自动每日刷新','records':[], 'success':0,'failed':1,
                'skipped':0,'error':str(exc)[:300]},'服务自动每日刷新：批量异常')
        time.sleep(60)


def mutate(store, route, p):
    with store.lock:
        u=universe(store)
        account=store.get('settings','account')
        if route=='/api/structures/scan':
            sid=e.symbol(p.get('symbol'))
            if sid not in u:raise ValueError('标的不存在')
            snapshot=structures.tracking(u[sid],e.now(),store.get('settings','structure:'+sid))
            return store.put('settings','structure:'+sid,snapshot,'用户手动扫描结构；仅记录研究快照')
        if route=='/api/refresh-preferences':
            if not isinstance(p.get('enabled'),bool):
                raise ValueError('enabled须为布尔值')
            return store.put('settings','refresh-preferences',{'enabled':p['enabled'],'time':'17:10','timezone':'Asia/Shanghai'},'用户更新自动联网刷新设置')
        if route=='/api/account':
            cur=p.get('base_currency','CNY')
            if cur not in ('CNY','HKD'):
                raise ValueError('本位币只支持CNY/HKD')
            if cur!=account['base_currency'] and any(t.get('fills') for t in store.list('trade')):
                raise ValueError('已有成交，禁止更换本位币以免混合绩效；请新建独立数据目录')
            a={'base_currency':cur,'asof':e.mathv1.iso(p['asof']),
               'pause_active':p.get('pause_active') is True,'holdings_complete':p.get('holdings_complete') is True}
            if a['asof']>e.now()[:10]:
                raise ValueError('账户日期不能在未来')
            for k in ('equity_base','cash_base','fx_hkd','fx_cny','exit_cost_reserve_base','drawdown_pct'):
                a[k]=e.num(p[k],k,positive=k in ('equity_base','fx_hkd','fx_cny'),nonnegative=True) if p.get(k) not in ('',None) else None
            a['drawdown_pct']=a['drawdown_pct'] or 0
            a['drawdown_episode_start']=(account.get('drawdown_episode_start') or a['asof']) if a['drawdown_pct']>=3 else ''
            for key in ('reviewed_loss_key','reviewed_drawdown_key','pause_review'):
                a[key]=account.get(key)
            a['fx_'+cur.lower()]=1
            if a['cash_base'] is not None and a['equity_base'] is not None and a['cash_base']>a['equity_base']:
                raise ValueError('现金不能高于所填净资产；请核对现金账户数据')
            return store.put('settings','account',a,'用户更新账户快照')
        if route=='/api/pause-review':
            state=e.pause_info(trades_view(store,u,account),u,account)
            if not state['can_review_release']:
                raise ValueError('尚无可解除的规则暂停，或两地基准数据不足5个后续交易日')
            account.update(reviewed_loss_key=state['loss_key'],reviewed_drawdown_key=state['drawdown_key'],
                           pause_review={'at':e.now(),'evidence':e.text(p.get('evidence'),'书面复核',5000),
                                         'state':state})
            return store.put('settings','account',account,'满5个交易日后书面复核：解除本次规则暂停')
        if route=='/api/instrument':
            i=e.instrument_input(p,u.get(p.get('id')))
            return store.put('instrument',i['id'],i,'新增或更新研究池资料')
        if route=='/api/observation':
            item=e.observation_input(p)
            items={i['id']:i for i in (store.get('settings','observations') or {}).get('items',[])}
            items[item['id']]=item
            store.put('settings','observations',{'items':list(items.values())},'新增或更新仅观察自选')
            return item
        if route in ('/api/import','/api/refresh'):
            sid=e.symbol(p.get('symbol'))
            if sid not in u:
                raise ValueError('请先添加标的')
            if p.get('confirmed') is not True:
                raise ValueError('须确认截止日已收盘')
            cutoff=e.mathv1.iso(p['through'])
            if cutoff==e.now()[:10] and e.now()[11:16]<'17:00':
                raise ValueError('当日行情请在北京时间17:00后导入或刷新')
            if route=='/api/refresh':
                bars,meta=download_daily(sid,cutoff,True)
            else:
                bars=e.csv_bars(e.text(p.get('csv'),'CSV',4000000),cutoff)
                meta={'source':e.text(p.get('source'),'来源',300), 'fetched_at':e.now(),
                      'adjustment':e.text(p.get('adjustment'),'复权口径',60),
                      'adjustment_verified':p.get('adjustment_verified') is True,
                      'completed_confirmed':True,'completed_through':cutoff,
                      'volume_unit':e.text(p.get('volume_unit'),'成交量单位',60),
                      'amount_unit':'报价币种' if p.get('amount_quote_confirmed') else '待核对',
                      'content_sha256':e.digest(bars),'status':'用户导入'}
                if any(b['amount'] is not None for b in bars) and not p.get('amount_quote_confirmed'):
                    raise ValueError('有amount列时，须确认成交额以报价币种计（不可填万元或亿）')
            i={**u[sid],'bars':bars,'meta':meta}
            return store.put('instrument',sid,i,'行情更新：'+meta['source'])
        if route=='/api/plan':
            ts=trades_view(store,u,account)
            result=e.plan(p,u,ts,account)
            if not account.get('holdings_complete'):
                result['missing'].append('尚未确认所有实战持仓已录入')
                result['sizing']=None
            if account.get('asof')!=result['asof']:
                result['missing'].append('账户与行情截止日不一致，须重新核对资产')
                result['sizing']=None
            result['snapshot_sha256']=e.digest(result)
            return store.put('plan','P-'+uuid.uuid4().hex[:10],result,'冻结候选研究计划')
        if route=='/api/trade':
            t=e.trade_input(p,u)
            if t['plan_id']:
                plan=store.get('plan',t['plan_id'])
                if not plan or plan['symbol']!=t['symbol']:
                    raise ValueError('关联计划不存在或标的不一致')
                t['initial_stop']=plan['initial_stop']
                t['buffer']=plan['buffer']
            # First fill in same transaction; no empty position can enter risk accounting.
            t['fills']=[e.fill_input(p['fill'],t['currency'],account['base_currency'])]
            if t['fills'][0]['side']!='buy':
                raise ValueError('一轮多头交易必须由买入开始')
            if t['plan_id'] and plan.get('sizing'):
                f=t['fills'][0];inputs=plan['sizing_inputs']
                t['initial_risk_base']=(f['quantity']*(f['price']-t['initial_stop']+inputs['roundtrip_cost_per_share_quote'])*f['fx']+inputs['fixed_cost_base']) if f['price']>t['initial_stop'] else None
                t['risk_basis']='实际首笔股数与成交价、成交汇率，加冻结计划成本预估；非整份计划股数'
            e.ledger(t)
            return store.put('trade','T-'+uuid.uuid4().hex[:10],t,'记录首笔实际或模拟成交')
        if route in ('/api/fill','/api/review','/api/correct','/api/void'):
            t=store.get('trade',e.text(p.get('id'),'交易编号',80))
            if not t or t.get('voided'):
                raise ValueError('有效交易记录不存在')
            reason='追加成交'
            if route=='/api/fill':
                t['fills'].append(e.fill_input(p,t['currency'],account['base_currency']))
            elif route=='/api/review':
                if p.get('adherence') not in ('yes','no','unknown'):
                    raise ValueError('无效纪律状态')
                t['adherence']=p['adherence']
                t['notes']=e.text(p.get('notes'),'复盘',4000,False)
                reason='更新事后复盘；买前理由保留'
            elif route=='/api/correct':
                reason='更正成交：'+e.text(p.get('reason'),'更正原因',500)
                index=int(p['index'])
                if index<0 or index>=len(t['fills']):
                    raise ValueError('成交序号不存在')
                t['fills'][index]=e.fill_input(p,t['currency'],account['base_currency'])
            else:
                reason='作废误录：'+e.text(p.get('reason'),'作废原因',500)
                t['voided']=True
                t['void_reason']=reason
            e.ledger(t)
            if route=='/api/correct' and int(p['index'])==0 and t.get('plan_id'):
                frozen=store.get('plan',t['plan_id'])
                if frozen and frozen.get('sizing'):
                    f=t['fills'][0];inputs=frozen['sizing_inputs']
                    t['initial_risk_base']=(f['quantity']*(f['price']-t['initial_stop']+inputs['roundtrip_cost_per_share_quote'])*f['fx']+inputs['fixed_cost_base']) if f['price']>t['initial_stop'] else None
            return store.put('trade',t['id'],t,reason)
        if route=='/api/proposal':
            return store.put('proposal','V-'+uuid.uuid4().hex[:10],e.proposal_input(p),'新增待验证迭代提案')
        raise ValueError('不支持的操作')


class Handler(BaseHTTPRequestHandler):
    server_version='ccWorkbench/1.0'

    def log_message(self, fmt, *args):
        if args and str(args[1] if len(args)>1 else '').startswith('5'):
            super().log_message(fmt,*args)

    def send(self, status, body, content_type='application/json; charset=utf-8', attachment=None):
        if isinstance(body,(dict,list)):
            if isinstance(body,dict):
                body={**body,'usage_notice':publication.NOTICE}
            body=json.dumps(body,ensure_ascii=False,allow_nan=False).encode('utf-8')
        elif isinstance(body,str):
            body=body.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type',content_type)
        self.send_header('Content-Length',str(len(body)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'")
        if attachment:
            self.send_header('Content-Disposition','attachment; filename="'+attachment+'"')
        self.end_headers()
        self.wfile.write(body)

    def host_ok(self):
        return self.headers.get('Host') in (f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}')

    def do_GET(self):
        if not self.host_ok():
            return self.send(403,{'error':'仅允许本机访问'})
        parsed=urlparse(self.path)
        route=parsed.path
        try:
            if route=='/api/state':
                return self.send(200,overview(self.server.store))
            if route in ('/api/detail','/api/research/report','/api/research/package'):
                sid=parse_qs(parsed.query).get('symbol',[''])[0]
                detail=detail_payload(self.server.store,sid)
                if route=='/api/research/report':
                    return self.send(200,research.markdown(detail['research']),'text/markdown; charset=utf-8',attachment=sid+'-trend-analysis.md')
                if route=='/api/research/package':
                    u=universe(self.server.store)
                    return self.send(200,research.ai_bundle(u[sid],u,detail['research']),attachment=sid+'-trend-ai-package.json')
                return self.send(200,detail)
            if route=='/api/replay':
                sid=parse_qs(parsed.query).get('symbol',[''])[0]
                u=universe(self.server.store)
                return self.send(200,e.replay(u[sid],u))
            if route=='/api/export':
                return self.send(200,self.server.store.export(),attachment='cc-workbench-backup.json')
            if route=='/api/audit':
                return self.send(200,self.server.store.audit(500))
            if route=='/api/refresh-status':
                return self.send(200,self.server.store.get('settings','refresh-status') or {'status':'尚未刷新'})
            if route=='/favicon.ico':
                return self.send(204,b'','image/x-icon')
            if route.startswith('/docs/'):
                path=(ROOT/route.lstrip('/')).resolve()
                allowed=ROOT/'docs'
            else:
                path=(ROOT/'static'/('index.html' if route=='/' else route.lstrip('/'))).resolve()
                allowed=ROOT/'static'
            if not path.is_relative_to(allowed) or not path.is_file():
                return self.send(404,{'error':'文件不存在'})
            mime=mimetypes.guess_type(path.name)[0] or 'text/plain'
            return self.send(200,path.read_bytes(),mime+('; charset=utf-8' if mime.startswith('text/') else ''))
        except (ValueError,KeyError,TypeError) as exc:
            self.send(400,{'error':str(exc)})
        except Exception:
            self.send(500,{'error':'读取失败；请检查本地日志或备份数据库'})

    def do_POST(self):
        origin=self.headers.get('Origin')
        expected=(f'http://127.0.0.1:{self.server.server_port}',f'http://localhost:{self.server.server_port}')
        if not self.host_ok() or origin not in (None,*expected) or self.headers.get('Content-Type','').split(';')[0]!='application/json':
            return self.send(403,{'error':'请从本机工作台提交JSON请求'})
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length<=0 or length>5000000:
                raise ValueError('请求应为1字节至5MB')
            p=json.loads(self.rfile.read(length))
            if not isinstance(p,dict):
                raise ValueError('需要JSON对象')
            route=urlparse(self.path).path
            result=refresh_all(self.server.store,p.get('reason','手动批量刷新')) if route=='/api/refresh-all' else mutate(self.server.store,route,p)
            self.send(200,{'ok':True,'result':result})
        except (ValueError,KeyError,TypeError,OverflowError) as exc:
            self.send(400,{'error':str(exc)})
        except Exception as exc:
            # Network errors don't overwrite current saved snapshot.
            self.send(502,{'error':'操作未完成，原记录保留：'+str(exc)[:240]})


def create_server(port=8766, data_dir=None, enable_scheduler=False):
    server=ThreadingHTTPServer(('127.0.0.1',port),Handler)
    server.store=Store(data_dir or ROOT/'data')
    server.shutdown_requested=False
    if enable_scheduler:
        threading.Thread(target=refresh_worker,args=(server,),name='daily-refresh',daemon=True).start()
    return server


if __name__=='__main__':
    parser=argparse.ArgumentParser(description='cc 股票工作台（仅本机）')
    parser.add_argument('--port',type=int,default=8766)
    parser.add_argument('--data-dir',type=Path)
    args=parser.parse_args()
    server=create_server(args.port,args.data_dir,enable_scheduler=True)
    print(f'cc 股票工作台 http://127.0.0.1:{server.server_port} | Ctrl+C 停止',flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown_requested=True
        server.server_close()
