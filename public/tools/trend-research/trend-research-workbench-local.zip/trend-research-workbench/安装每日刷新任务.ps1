param([string]$Time='17:20')
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$task='cc-stock-workbench-daily-refresh'
$script=Join-Path $root 'daily_refresh.ps1'
$ps=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$action=New-ScheduledTaskAction -Execute $ps -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$script`""
$at=[datetime]::ParseExact($Time,'HH:mm',$null)
$trigger=New-ScheduledTaskTrigger -Daily -At $at
$principal=New-ScheduledTaskPrincipal -UserId ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Limited
Register-ScheduledTask -TaskName $task -Action $action -Trigger $trigger -Principal $principal -Description 'cc 股票投资工作台：每日收盘后刷新港股/A股研究池' -Force | Out-Null
$check=Get-ScheduledTask -TaskName $task -ErrorAction Stop
if ($check.TaskName -ne $task) { throw '任务创建后校验失败' }
Write-Output "已创建每日 $Time（本机时间）刷新任务：$task"
Write-Output '任务会刷新港股/A股研究池；美股仅观察条目会跳过。'
