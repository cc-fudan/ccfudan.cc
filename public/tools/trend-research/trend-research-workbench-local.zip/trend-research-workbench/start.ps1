param([switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$appRoot = $PSScriptRoot
$port = 8766
$url = "http://127.0.0.1:$port"
function Get-WorkbenchState {
    $request = [System.Net.HttpWebRequest]::Create("$url/api/state")
    $request.Proxy = $null
    $request.Timeout = 1500
    $response = $request.GetResponse()
    $reader = New-Object System.IO.StreamReader($response.GetResponseStream())
    try { return ($reader.ReadToEnd() | ConvertFrom-Json) }
    finally { $reader.Dispose(); $response.Dispose() }
}
try {
    $state = Get-WorkbenchState
    if ($state.version -and $state.stocks) { if (-not $NoBrowser) { Start-Process $url }; exit 0 }
} catch {}
$pythonPath = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
if (-not (Test-Path -LiteralPath $pythonPath)) {
    $pythonCmd = Get-Command python -ErrorAction SilentlyContinue
    if (-not $pythonCmd) { throw 'Python 3.10+ is required. Install Python and run this launcher again.' }
    $pythonPath = $pythonCmd.Source
}
& $pythonPath -c 'import sys; assert sys.version_info >= (3,10), "Python 3.10+ required"'
if ($LASTEXITCODE -ne 0) { throw 'Python 3.10+ is required.' }
$dataDir = Join-Path $appRoot 'data'
New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
$scriptPath = Join-Path $appRoot 'app.py'
$serverProc = Start-Process -FilePath $pythonPath -ArgumentList @('"'+$scriptPath+'"','--port',"$port") -WorkingDirectory $appRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $dataDir 'server.log') -RedirectStandardError (Join-Path $dataDir 'error.log') -PassThru
@{ pid=$serverProc.Id; app=$scriptPath; port=$port; executable=$serverProc.Path; startedUtcTicks=$serverProc.StartTime.ToUniversalTime().Ticks.ToString() } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $dataDir 'server-process.json') -Encoding UTF8
for ($attempt=0; $attempt -lt 20; $attempt++) {
    Start-Sleep -Milliseconds 350
    try {
        $state=Get-WorkbenchState
        if ($state.version) { if (-not $NoBrowser) { Start-Process $url }; exit 0 }
    } catch {}
    if ($serverProc.HasExited) { break }
}
throw "Server did not start. Check data/error.log. Port $port may already be in use."
